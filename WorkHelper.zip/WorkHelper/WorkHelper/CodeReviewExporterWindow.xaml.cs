﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using WorkHelper.Common;

namespace WorkHelper
{
    public class CodeReviewItem
    {
        public string Sha { get; set; }
        public string Filename { get; set; }
        public string Url { get; set; }
        public string Lines { get; set; }
        public string Title { get; set; }
        public string Comment { get; set; }
        public string Priority { get; set; }
        public string Category { get; set; }
        public string Additional { get; set; }
        public string Id { get; set; }
        public string Private { get; set; }
    }

    /// <summary>
    /// Interaction logic for CodeReviewExporterWindow.xaml
    /// </summary>
    public partial class CodeReviewExporterWindow : Window
    {
        private List<CodeReviewItem> _reviewItems = new List<CodeReviewItem>();
        private ExcelHelper _excelHelper;

        public CodeReviewExporterWindow()
        {
            InitializeComponent();
            dateReviewRequest.SelectedDate = DateTime.Now;
            dateInitialReview.SelectedDate = DateTime.Now;
        }

        private void BtnSelectFile_Click(object sender, RoutedEventArgs e)
        {
            var openFileDialog = new OpenFileDialog
            {
                Filter = "CSV Files (*.csv)|*.csv|All Files (*.*)|*.*",
                Title = "Select Code Review CSV File"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                txtFilePath.Text = openFileDialog.FileName;
                ParseCsvFile(openFileDialog.FileName);
            }
        }

        private void ParseCsvFile(string filePath)
        {
            try
            {
                _reviewItems.Clear();

                // Read all lines from the CSV file
                string[] lines = File.ReadAllLines(filePath, Encoding.UTF8);

                // Skip header line
                for (int i = 1; i < lines.Length; i++)
                {
                    string line = lines[i];
                    if (string.IsNullOrWhiteSpace(line))
                        continue;

                    // Parse CSV line - handling quoted fields correctly
                    var fields = ParseCsvLine(line);

                    if (fields.Length >= 11)
                    {
                        var item = new CodeReviewItem
                        {
                            Sha = fields[0],
                            Filename = fields[1],
                            Url = fields[2],
                            Lines = fields[3],
                            Title = fields[4],
                            Comment = fields[5],
                            Priority = fields[6],
                            Category = fields[7],
                            Additional = fields[8],
                            Id = fields[9],
                            Private = fields[10]
                        };
                        if(!string.IsNullOrEmpty(item.Comment))
                        {
                            // replace ¥n to newline from
                            item.Comment = item.Comment.Replace("\\n",Environment.NewLine);
                        }
                        if (!string.IsNullOrEmpty(item.Filename))
                        {
                            // replace ¥n to newline from
                            item.Filename = item.Filename.Replace(@"\", "");
                        }

                        _reviewItems.Add(item);
                    }
                }

                // Update status and enable export button if we have items
                lblStatus.Content = $"Loaded {_reviewItems.Count} review items";
                btnExport.IsEnabled = _reviewItems.Count > 0;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error parsing CSV file: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                lblStatus.Content = "Error loading file";
                btnExport.IsEnabled = false;
            }
        }

        private string[] ParseCsvLine(string line)
        {
            List<string> fields = new List<string>();
            bool inQuotes = false;
            StringBuilder currentField = new StringBuilder();

            for (int i = 0; i < line.Length; i++)
            {
                char c = line[i];

                if (c == '\"')
                {
                    // Toggle quote state
                    inQuotes = !inQuotes;
                }
                else if (c == ',' && !inQuotes)
                {
                    // End of field, add to list and reset
                    fields.Add(currentField.ToString().Trim('\"'));
                    currentField.Clear();
                }
                else
                {
                    // Regular character, add to current field
                    currentField.Append(c);
                }
            }

            // Add the last field
            fields.Add(currentField.ToString().Trim('\"'));

            return fields.ToArray();
        }

        private void BtnExport_Click(object sender, RoutedEventArgs e)
        {
            if (_reviewItems.Count == 0)
            {
                MessageBox.Show("No review items to export.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Validate user inputs
            if (string.IsNullOrWhiteSpace(txtReviewee.Text) ||
                string.IsNullOrWhiteSpace(txtReviewTarget.Text) ||
                string.IsNullOrWhiteSpace(txtReviewer.Text) ||
                dateReviewRequest.SelectedDate == null ||
                dateInitialReview.SelectedDate == null)
            {
                MessageBox.Show("Please fill in all required fields.", "Warning", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                _excelHelper = new ExcelHelper();
                if (_excelHelper.CreateNewExcel())
                {
                    ExportToExcel();
                    MessageBox.Show("Export completed successfully!", "Success", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                else
                {
                    MessageBox.Show("Failed to create Excel document.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error exporting to Excel: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void ExportToExcel()
        {
            // Write headers
            string[] headers = {
                "No.", "レビュー依頼日", "レビューイ", "レビュー対象物（集計用）",
                "レビュー対象物", "レビュー対象箇所（ページ／シート）", "チケット番号", "ステータス",
                "レビュー日付（初回）", "レビュアー", "指摘分類", "指摘内容"
            };

            for (int i = 0; i < headers.Length; i++)
            {
                _excelHelper.WriteToCell(1, i + 1, headers[i]);
                _excelHelper.FormatCell(1, i + 1, "#CCCCCC", true);
            }

            // Get user input values
            string reviewRequestDate = dateReviewRequest.SelectedDate?.ToString("yyyy/MM/dd") ?? "";
            string reviewee = txtReviewee.Text;
            string reviewTarget = txtReviewTarget.Text;
            string initialReviewDate = dateInitialReview.SelectedDate?.ToString("yyyy/MM/dd") ?? "";
            string reviewer = txtReviewer.Text;

            // Write data rows
            for (int i = 0; i < _reviewItems.Count; i++)
            {
                var item = _reviewItems[i];
                int row = i + 2; // Start from row 2 (after headers)

                // No.
                _excelHelper.WriteToCell(row, 1, i + 1);

                // レビュー依頼日
                _excelHelper.WriteToCell(row, 2, reviewRequestDate);

                // レビューイ
                _excelHelper.WriteToCell(row, 3, reviewee);

                // レビュー対象物（集計用）
                _excelHelper.WriteToCell(row, 4, reviewTarget);

                // レビュー対象物
                _excelHelper.WriteToCell(row, 5, item.Filename);

                // レビュー対象箇所（ページ／シート）
                _excelHelper.WriteToCell(row, 6, item.Lines);

                // チケット番号
                _excelHelper.WriteToCell(row, 7, "");

                // ステータス
                _excelHelper.WriteToCell(row, 8, "新规");

                // レビュー日付（初回）
                _excelHelper.WriteToCell(row, 9, initialReviewDate);

                // レビュアー
                _excelHelper.WriteToCell(row, 10, reviewer);

                // 指摘分類
                _excelHelper.WriteToCell(row, 11, item.Category);

                // 指摘内容 (title + newline + comment)
                _excelHelper.WriteToCell(row, 12, $"{item.Title}{Environment.NewLine}{item.Comment}");
            }

            // Auto-adjust column widths for better readability
            _excelHelper.AutoFitColumns();

            // Make sure the content column is wide enough for comments
            _excelHelper.GetWorksheet().Columns[12].ColumnWidth = 50;
        }

        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            // Clean up resources
            if (_excelHelper != null)
            {
                _excelHelper.CleanUp();
            }
        }
    }
}