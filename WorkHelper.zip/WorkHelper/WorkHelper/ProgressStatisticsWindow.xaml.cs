﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using WorkHelper.Common;

namespace WorkHelper
{
    /// <summary>
    /// 进度统计窗口，用于按起因统计Excel数据
    /// </summary>
    public partial class ProgressStatisticsWindow : Window
    {
        private readonly ExcelStatisticsUtility _statisticsUtility;
        private List<AggInfo> _results;

        public ProgressStatisticsWindow()
        {
            InitializeComponent();
            _statisticsUtility = new ExcelStatisticsUtility();
            _results = new List<AggInfo>();

            // 设置默认日期
            SetDefaultDates();
        }

        /// <summary>
        /// 设置默认日期（当前周的周三及上下周的周三）
        /// </summary>
        private void SetDefaultDates()
        {
            DateTime now = DateTime.Now;

            // 获取当前周的周三
            int daysUntilWednesday = ((int)DayOfWeek.Wednesday - (int)now.DayOfWeek + 7) % 7;
            DateTime thisWednesday = now.AddDays(daysUntilWednesday);

            // 如果今天是周三之后的日子，那么取下周的周三
            if (daysUntilWednesday == 0 && now.TimeOfDay > new TimeSpan(12, 0, 0))
                thisWednesday = thisWednesday.AddDays(7);
            else if (daysUntilWednesday < 0)
                thisWednesday = thisWednesday.AddDays(7);

            // 设置日期控件的值
            dpLastWednesday.SelectedDate = thisWednesday.AddDays(-7);
            dpThisWednesday.SelectedDate = thisWednesday;
            dpNextWednesday.SelectedDate = thisWednesday.AddDays(7);
        }

        /// <summary>
        /// 选择Excel文件按钮点击事件
        /// </summary>
        private void BtnSelectExcel_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
            {
                Filter = "Excel文件|*.xlsx;*.xls",
                Title = "选择Excel文件"
            };

            if (dialog.ShowDialog() == true)
            {
                txtExcelPath.Text = dialog.FileName;
            }
        }

        /// <summary>
        /// 计算统计按钮点击事件
        /// </summary>
        private void BtnCalculate_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtExcelPath.Text))
            {
                MessageBox.Show("请先选择Excel文件", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // 检查日期是否已选择
            if (!dpLastWednesday.SelectedDate.HasValue ||
                !dpThisWednesday.SelectedDate.HasValue ||
                !dpNextWednesday.SelectedDate.HasValue)
            {
                MessageBox.Show("请选择所有需要的日期", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                SetControlsState(false);
                progressBar.Visibility = Visibility.Visible;
                UpdateStatus("开始计算统计数据...");

                // 获取选择的日期
                DateTime lastWednesday = dpLastWednesday.SelectedDate.Value;
                DateTime thisWednesday = dpThisWednesday.SelectedDate.Value;
                DateTime nextWednesday = dpNextWednesday.SelectedDate.Value;

                // 执行统计
                _results = _statisticsUtility.CalculateStatistics(
                    txtExcelPath.Text,
                    lastWednesday,
                    thisWednesday,
                    nextWednesday,
                    UpdateStatus);

                // 绑定结果到数据网格
                dgResults.ItemsSource = _results;

                UpdateStatus($"计算完成！共统计 {_results.Count} 个起因项。");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"处理过程中出错: {ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                UpdateStatus($"处理失败: {ex.Message}");
            }
            finally
            {
                SetControlsState(true);
                progressBar.Visibility = Visibility.Collapsed;
            }
        }

        /// <summary>
        /// 导出CSV按钮点击事件
        /// </summary>
        private void BtnExport_Click(object sender, RoutedEventArgs e)
        {
            if (_results == null || _results.Count == 0)
            {
                MessageBox.Show("没有可导出的数据，请先执行统计计算", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                SetControlsState(false);
                progressBar.Visibility = Visibility.Visible;

                // 导出结果到CSV
                bool success = _statisticsUtility.ExportToCsv(_results, UpdateStatus);

                if (success)
                {
                    UpdateStatus("导出成功！");
                }
                else
                {
                    UpdateStatus("导出取消或失败");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"导出过程中出错: {ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                UpdateStatus($"导出失败: {ex.Message}");
            }
            finally
            {
                SetControlsState(true);
                progressBar.Visibility = Visibility.Collapsed;
            }
        }

        /// <summary>
        /// 设置控件状态
        /// </summary>
        private void SetControlsState(bool enabled)
        {
            btnSelectExcel.IsEnabled = enabled;
            btnCalculate.IsEnabled = enabled;
            btnExport.IsEnabled = enabled;
            dpLastWednesday.IsEnabled = enabled;
            dpThisWednesday.IsEnabled = enabled;
            dpNextWednesday.IsEnabled = enabled;
        }

        /// <summary>
        /// 更新状态栏文本
        /// </summary>
        private void UpdateStatus(string message)
        {
            txtStatus.Text = message;
        }
    }
}