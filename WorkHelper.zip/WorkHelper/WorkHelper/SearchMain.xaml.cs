﻿using Microsoft.Win32;
using System.Data.SQLite;
using System.Diagnostics;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using WorkHelper.Common;

namespace WorkHelper
{
    /// <summary>
    /// SearchMain.xaml の相互作用ロジック
    /// </summary>
    public partial class SearchMain : Window
    {
        private readonly DocumentSearcher _documentSearcher;
        private CancellationTokenSource _cancellationTokenSource;
        private bool _isSearching;
        private SearchResultsWindow _resultsWindow;


        public SearchMain()
        {
            InitializeComponent();
            _documentSearcher = new DocumentSearcher();
            UpdateUIState(false);
        }

        private void UpdateUIState(bool isSearching)
        {
            _isSearching = isSearching;
            txtFolderPath.IsEnabled = !isSearching;
            txtKeyword.IsEnabled = !isSearching;
            btnSearch.IsEnabled = !isSearching && !string.IsNullOrWhiteSpace(txtFolderPath.Text);
            btnStop.IsEnabled = isSearching;
            btnViewResults.IsEnabled = !isSearching;
            btnExport.IsEnabled = !isSearching;
        }

        private void BtnSelectFolder_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new Microsoft.Win32.OpenFolderDialog
            {
                Title = "选择文件夹"
            };

            if (dialog.ShowDialog() == true)
            {
                txtFolderPath.Text = dialog.FolderName;
            }
        }

        public async Task<List<SearchResult>> Search(string keyword)
        {
            using var connection = new SQLiteConnection(@"Data Source=C:\work\sqlitedb.db;Version=3;");
            await connection.OpenAsync();

            var results = new List<SearchResult>();

            // FTS4 的搜索语法
            const string searchSql = @"
        SELECT d.file_path, d.file_type, dp.location, dp.page_number, dp.content
        FROM DocumentPages_fts fts
        JOIN DocumentPages dp ON dp.document_id = fts.document_id AND dp.page_number = fts.page_number
        JOIN Documents d ON d.id = dp.document_id
        WHERE DocumentPages_fts MATCH @keyword;";

            using var cmd = new SQLiteCommand(searchSql, connection);
            cmd.Parameters.AddWithValue("@keyword", keyword);

            using var reader = await cmd.ExecuteReaderAsync();
            while (await reader.ReadAsync())
            {
                results.Add(new SearchResult
                {
                    FilePath = reader.GetString(0),
                    FileType = reader.GetString(1),
                    Location = reader.GetString(2),
                    PageNumber = reader.GetInt32(3),
                    Context = ExtractContext(reader.GetString(4), keyword)
                });
            }

            return results;
        }

        private string ExtractContext(string content, string keyword)
        {
            // 提取关键词前后的上下文
            int keywordIndex = content.IndexOf(keyword, StringComparison.OrdinalIgnoreCase);
            if (keywordIndex == -1) return content;

            int contextLength = 100;
            int startIndex = Math.Max(0, keywordIndex - contextLength);
            int length = Math.Min(content.Length - startIndex, contextLength * 2);

            return content.Substring(startIndex, length);
        }

        private async void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFolderPath.Text))
            {
                MessageBox.Show("请选择搜索目录", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtKeyword.Text))
            {
                MessageBox.Show("请输入搜索关键词", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // 开始新的搜索
            _cancellationTokenSource = new CancellationTokenSource();
            UpdateUIState(true);
            progressBar.IsIndeterminate = true;
            lstStatus.Items.Clear();

            try
            {

                // 在启动搜索前获取所需的值
                string folderPath = txtFolderPath.Text;
                string keyword = txtKeyword.Text;


                await Task.Run(() =>
                {
                    AddSearchStatus("开始搜索...");

                    _documentSearcher.SearchInDirectory(
                        folderPath,
                        keyword
                    , (status) => AddSearchStatus(status),
                    _cancellationTokenSource.Token
                    );

                    if (!_cancellationTokenSource.Token.IsCancellationRequested)
                    {
                        AddSearchStatus("搜索完成！");
                    }
                }, _cancellationTokenSource.Token);
            }
            catch (OperationCanceledException)
            {
                AddSearchStatus("搜索已取消");
            }
            catch (Exception ex)
            {
                AddSearchStatus($"搜索出错: {ex.Message}");
                MessageBox.Show(ex.Message, "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                progressBar.IsIndeterminate = false;
                UpdateUIState(false);
            }
        }

        private void BtnStop_Click(object sender, RoutedEventArgs e)
        {
            if (_isSearching && _cancellationTokenSource != null)
            {
                _cancellationTokenSource.Cancel();
                AddSearchStatus("正在停止搜索...");
            }
        }

        private void BtnViewResults_Click(object sender, RoutedEventArgs e)
        {
            if (_resultsWindow == null || !_resultsWindow.IsLoaded)
            {
                _resultsWindow = new SearchResultsWindow(_documentSearcher.SearchResults);
                _resultsWindow.Show();
            }
            else
            {
                _resultsWindow.Activate();
                _resultsWindow.UpdateResults(_documentSearcher.SearchResults);
            }
        }

        private void BtnExport_Click(object sender, RoutedEventArgs e)
        {
            if (_documentSearcher.SearchResults.Count == 0)
            {
                MessageBox.Show("没有可导出的搜索结果", "提示", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var saveFileDialog = new SaveFileDialog
            {
                Filter = "Excel文件|*.xlsx",
                DefaultExt = ".xlsx",
                FileName = $"搜索结果_{DateTime.Now:yyyyMMdd_HHmmss}"
            };

            if (saveFileDialog.ShowDialog() == true)
            {
                try
                {
                    Mouse.OverrideCursor = Cursors.Wait;
                    _documentSearcher.ExportResultsToExcel(saveFileDialog.FileName);
                    MessageBox.Show("导出完成！", "提示", MessageBoxButton.OK, MessageBoxImage.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"导出失败: {ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                finally
                {
                    Mouse.OverrideCursor = null;
                }
            }
        }

        private void AddSearchStatus(string status)
        {
            // 在UI线程上更新状态列表
            Dispatcher.Invoke(() =>
            {
                lstStatus.Items.Add($"[{DateTime.Now:HH:mm:ss}] {status}");
                lstStatus.ScrollIntoView(lstStatus.Items[lstStatus.Items.Count - 1]);
            });
        }

        private void txtKeyword_TextChanged(object sender, TextChangedEventArgs e)
        {
            UpdateUIState(false);
        }

        private async void BtnBuildIndex(object sender, RoutedEventArgs e)
        {
            try
            {
                Debug.WriteLine("Start build doc index :" + DateTime.Now.ToString());
                Mouse.OverrideCursor = Cursors.Wait;
                var indexer = new DocumentIndexer();
                await indexer.IndexDirectory(txtFolderPath.Text);
                Debug.WriteLine("End build doc index :" + DateTime.Now.ToString());

                MessageBox.Show("索引创建完成！", "提示", MessageBoxButton.OK, MessageBoxImage.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"创建索引时出错: {ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                Mouse.OverrideCursor = null;
            }
        
        }

        private async void btnSearchDB_Click(object sender, RoutedEventArgs e)
        {
            _documentSearcher.SearchResults = await Search(txtKeyword.Text);
        }
    }
}
