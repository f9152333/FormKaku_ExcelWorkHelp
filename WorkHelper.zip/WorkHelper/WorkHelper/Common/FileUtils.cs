﻿using System;
using System.IO;
using System.Text;
using System.Collections.Generic;
using System.Security.Cryptography;
using System.Threading.Tasks;
using System.Diagnostics;
using System.Configuration;


namespace WorkHelper.Common
{

    public static class FileUtils
    {
        public static class Temp
        {
            public static string tempPath = Path.Combine(Path.GetTempPath(), "HelperTemp");
            /// <summary>
            /// 打开系统临时文件夹
            /// </summary>
            public static void OpenTempFolder()
            {
                try
                {
                    Directory.CreateDirectory(tempPath);
                    Process.Start("explorer.exe", tempPath);
                }
                catch (Exception ex)
                {
                    throw new Exception("打开临时文件夹失败", ex);
                }
            }


            /// <summary>
            /// 获取指定文件在临时文件夹中的路径
            /// </summary>
            public static string GetTempFilePath(string fileName)
            {
                return Path.Combine(tempPath, fileName);
            }

            /// <summary>
            /// 在临时文件夹中创建唯一文件名
            /// </summary>
            public static string CreateUniqueTempPath(string prefix = "", string extension = "")
            {
                prefix = string.IsNullOrEmpty(prefix) ? "" : prefix + "_";
                extension = string.IsNullOrEmpty(extension) ? "" :
                           extension.StartsWith(".") ? extension : "." + extension;

                return Path.Combine(
                    Path.GetTempPath(),
                    $"{prefix}{DateTime.Now:yyyyMMddHHmmss}_{Guid.NewGuid():N}{extension}"
                );
            }

            /// <summary>
            /// 在临时文件夹中创建子文件夹
            /// </summary>
            public static string CreateTempSubFolder(string folderName)
            {
                string path = Path.Combine(tempPath, folderName);
                Directory.CreateDirectory(path);
                return path;
            }
        }

        public static class Hash
        {
            /// <summary>
            /// 计算文件的MD5值
            /// </summary>
            public static string GetMD5(string filePath)
            {
                using (var md5 = MD5.Create())
                using (var stream = File.OpenRead(filePath))
                {
                    byte[] hash = md5.ComputeHash(stream);
                    return BitConverter.ToString(hash).Replace("-", "").ToLowerInvariant();
                }
            }
        }

        public static class Size
        {
            /// <summary>
            /// 获取文件大小的友好显示
            /// </summary>
            public static string GetFriendlySize(long bytes)
            {
                string[] sizes = { "B", "KB", "MB", "GB", "TB" };
                double len = bytes;
                int order = 0;

                while (len >= 1024 && order < sizes.Length - 1)
                {
                    order++;
                    len = len / 1024;
                }

                return $"{len:0.##} {sizes[order]}";
            }
        }
    }
}
