﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using System.Text;
using Microsoft.Win32;
using Microsoft.Office.Interop.Excel;
using System.Windows;
using System.Windows.Input;

namespace WorkHelper.Common
{

    public class AggInfo
    {
        public string KeyNo { get; set; }               // 起因
        public string FunctionName { get; set; }        // 機能名
        public int TotalCount { get; set; }             // ファイル数
        public int TotalPageCount { get; set; }         // 総ページ数
        public int LastWeekCount { get; set; }          // 先週まで完了数
        public int ThisWeekStartCount { get; set; }     // 今週着手数
        public int ThisWeekEndCount { get; set; }       // 今週完了数
        public int NextWeekStartCount { get; set; }     // 来週着手数
        public int NextWeekEndCount { get; set; }       // 来週完了数
        public DateTime? MinStartTime { get; set; }     // 最小開始日
        public DateTime? MaxEndTime { get; set; }       // 最大終了日

        public List<DateTime> StartTimes { get; set; }  // 開始日リスト
        public List<DateTime> EndTimes { get; set; }   // 終了日リスト
    }

    /// <summary>
    /// 用于Excel统计的工具类，专门处理按起因统计的数据
    /// </summary>
    public class ExcelStatisticsUtility
    {
        private readonly OfficeManager _officeManager;

        // 列索引常量
        private const int COL_CAUSE_KEY = 2;      // 起因列（第2列）
        private const int COL_PAGE = 10;         // ページ列（第10列）
        private const int COL_STATUS = 11;        // 状态列（第11列）
        private const int COL_START_DATE = 15;    // 开始日期列（第15列）
        private const int COL_END_DATE = 16;      // 完成日期列（第16列）
        private const int COL_TARGET_SIGN = 7;      // 対象列

        // 完成状态标记
        private const string STATUS_COMPLETED = "【修正】完了";
        private const string TARGET_SIGN = "○";

        public ExcelStatisticsUtility()
        {
            _officeManager = OfficeManager.Instance;
        }

        /// <summary>
        /// 执行统计并生成汇总数据
        /// </summary>
        /// <param name="excelPath">Excel文件路径</param>
        /// <param name="lastWednesday">上周三日期</param>
        /// <param name="thisWednesday">本周三日期</param>
        /// <param name="nextWednesday">下周三日期</param>
        /// <param name="statusCallback">状态更新回调</param>
        /// <returns>统计结果列表</returns>
        public List<AggInfo> CalculateStatistics(
            string excelPath,
            DateTime lastWednesday,
            DateTime thisWednesday,
            DateTime nextWednesday,
            Action<string> statusCallback = null)
        {
            UpdateStatus(statusCallback, "正在计算统计数据...");

            var results = new List<AggInfo>();
            var causeFunctionMap = new Dictionary<string, string>();

            // 使用 using 确保资源释放
            using (var excel = _officeManager.CreateExcelHelper())
            {
                try
                {
                    if (!excel.OpenExcelSilently(excelPath))
                    {
                        UpdateStatus(statusCallback, "无法打开Excel文件");
                        return results;
                    }

                    var workbook = excel.GetWorkbook();

                    // 首先从"起因一覧"表中读取起因和功能名的映射
                    LoadCauseFunctionMapping(workbook, ref causeFunctionMap, statusCallback);

                    // 然后从第一个工作表获取统计数据
                    CalculateStatisticsFromSheet(workbook.Sheets[1] as Worksheet,
                        causeFunctionMap,
                        lastWednesday,
                        thisWednesday,
                        nextWednesday,
                        ref results,
                        statusCallback);

                    UpdateStatus(statusCallback, $"统计完成！共处理 {results.Count} 个起因项。");
                    return results;
                }
                catch (Exception ex)
                {
                    UpdateStatus(statusCallback, $"处理过程中出错: {ex.Message}");
                    throw;
                }
            }
        }

        /// <summary>
        /// 从起因一览表加载起因和功能名的映射关系
        /// </summary>
        private void LoadCauseFunctionMapping(
            Workbook workbook,
            ref Dictionary<string, string> causeFunctionMap,
            Action<string> statusCallback)
        {
            try
            {
                // 查找名为"起因一覧"的工作表
                Worksheet causesSheet = null;
                foreach (Worksheet sheet in workbook.Sheets)
                {
                    if (sheet.Name == "起因一覧")
                    {
                        causesSheet = sheet;
                        break;
                    }
                }

                if (causesSheet == null)
                {
                    UpdateStatus(statusCallback, "未找到'起因一覧'工作表");
                    return;
                }

                UpdateStatus(statusCallback, "正在读取起因和功能名映射...");

                // 获取最后一行
                int lastRow = causesSheet.Cells.SpecialCells(XlCellType.xlCellTypeLastCell).Row;

                // 遍历工作表行
                for (int row = 2; row <= lastRow; row++) // 从第2行开始（跳过标题行）
                {
                    var causeKey = causesSheet.Cells[row, 1].Text?.ToString(); // 第1列是起因
                    var functionName = causesSheet.Cells[row, 2].Text?.ToString(); // 第2列是功能名
                    var target = causesSheet.Cells[row, 3].Text?.ToString(); // 第3列是対象列

                    if (!string.Equals(target, TARGET_SIGN))
                        continue;

                    if (!string.IsNullOrWhiteSpace(causeKey) && !string.IsNullOrWhiteSpace(functionName))
                    {
                        causeFunctionMap[causeKey] = functionName;
                    }
                }

                UpdateStatus(statusCallback, $"成功读取 {causeFunctionMap.Count} 个起因和功能名映射");
            }
            catch (Exception ex)
            {
                UpdateStatus(statusCallback, $"读取起因一览时出错: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// 从工作表计算统计数据
        /// </summary>
        private void CalculateStatisticsFromSheet(
            Worksheet worksheet,
            Dictionary<string, string> causeFunctionMap,
            DateTime lastWednesday,
            DateTime thisWednesday,
            DateTime nextWednesday,
            ref List<AggInfo> results,
            Action<string> statusCallback)
        {
            try
            {
                UpdateStatus(statusCallback, "正在计算统计数据...");

                // 获取最后一行
                int lastRow = worksheet.Cells.SpecialCells(XlCellType.xlCellTypeLastCell).Row;

                // 初始化统计数据字典
                var statsDictionary = new Dictionary<string, AggInfo>();

                // 遍历工作表行
                for (int row = 3; row <= lastRow; row++) // 从第3行开始（跳过标题行）
                {
                    // 获取起因键
                    var causeKey = worksheet.Cells[row, COL_CAUSE_KEY].Text?.ToString();
                    if (string.IsNullOrWhiteSpace(causeKey))
                        continue;

                    // 获取对象列
                    var target = worksheet.Cells[row, COL_TARGET_SIGN].Text?.ToString();
                    if (!string.Equals(target,TARGET_SIGN))
                        continue;

                    // 如果当前起因还未添加到统计中，初始化它
                    if (!statsDictionary.ContainsKey(causeKey))
                    {
                        var functionName = causeFunctionMap.ContainsKey(causeKey) ?
                            causeFunctionMap[causeKey] : string.Empty;

                        statsDictionary[causeKey] = new AggInfo
                        {
                            KeyNo = causeKey,
                            FunctionName = functionName,
                            TotalPageCount = 0,
                            TotalCount = 0,
                            LastWeekCount = 0,
                            ThisWeekStartCount = 0,
                            ThisWeekEndCount = 0,
                            NextWeekStartCount = 0,
                            NextWeekEndCount = 0,
                            MinStartTime = null,
                            MaxEndTime = null,
                            StartTimes = new List<DateTime>(),
                            EndTimes = new List<DateTime>(),
                        };
                    }

                    // 增加该起因的总文件数
                    statsDictionary[causeKey].TotalCount++;

                    // 获取状态、开始日期和完成日期
                    var status = worksheet.Cells[row, COL_STATUS].Text?.ToString();
                    var startDateText = worksheet.Cells[row, COL_START_DATE].Text?.ToString();
                    var endDateText = worksheet.Cells[row, COL_END_DATE].Text?.ToString();
                    var pageText = worksheet.Cells[row,COL_PAGE].Text?.ToString();

                    if (double.TryParse(pageText, out double value))
                    {
                        statsDictionary[causeKey].TotalPageCount += value;
                    }

                    if (!string.IsNullOrWhiteSpace(startDateText))
                    {
                        if (DateTime.TryParse(startDateText, out DateTime date))
                        {
                            statsDictionary[causeKey].StartTimes.Add(date);
                        }
                    }

                    if (!string.IsNullOrWhiteSpace(endDateText))
                    {
                        if (DateTime.TryParse(endDateText, out DateTime date))
                        {
                            statsDictionary[causeKey].EndTimes.Add(date);
                        }
                    }

                    // 解析日期
                    DateTime? startDate = ParseDateTime(startDateText);
                    DateTime? endDate = ParseDateTime(endDateText);

                    
                        // 计算各统计项
                        if (endDate.HasValue && endDate.Value <= lastWednesday)
                        {
                            statsDictionary[causeKey].LastWeekCount++;
                        }

                        if (startDate.HasValue &&
                            startDate.Value > lastWednesday &&
                            startDate.Value <= thisWednesday)
                        {
                            statsDictionary[causeKey].ThisWeekStartCount++;
                        }

                        if (endDate.HasValue &&
                            endDate.Value > lastWednesday &&
                            endDate.Value <= thisWednesday)
                        {
                            statsDictionary[causeKey].ThisWeekEndCount++;
                        }

                        if (startDate.HasValue &&
                            startDate.Value > thisWednesday &&
                            startDate.Value <= nextWednesday)
                        {
                            statsDictionary[causeKey].NextWeekStartCount++;
                        }

                        if (endDate.HasValue &&
                            endDate.Value > thisWednesday &&
                            endDate.Value <= nextWednesday)
                        {
                            statsDictionary[causeKey].NextWeekEndCount++;
                        }
                    
                }
                // 将字典转换为列表返回
                results.AddRange(statsDictionary.Values);

                foreach (var result in results)
                {
                    if (result.StartTimes.Count > 0)
                    {
                        result.MinStartTime = result.StartTimes.Min();
                    }
                    if (result.EndTimes.Count > 0)
                    {
                        result.MaxEndTime = result.EndTimes.Max();
                    }
                }
                UpdateStatus(statusCallback, $"已处理 {results.Count} 个统计项");
            }
            catch (Exception ex)
            {
                UpdateStatus(statusCallback, $"计算统计数据时出错: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// 将统计结果导出到CSV文件
        /// </summary>
        /// <param name="results">统计结果列表</param>
        /// <param name="statusCallback">状态更新回调</param>
        /// <returns>是否成功导出</returns>
        public bool ExportToCsv(List<AggInfo> results, Action<string> statusCallback = null)
        {
            try
            {
                var saveDialog = new SaveFileDialog
                {
                    Filter = "CSV文件|*.csv",
                    Title = "保存统计结果",
                    FileName = $"进度统计_{DateTime.Now:yyyyMMdd_HHmmss}.csv"
                };

                if (saveDialog.ShowDialog() != true)
                    return false;

                UpdateStatus(statusCallback, "正在导出统计结果...");

                var csv = new StringBuilder();
                // 添加CSV标题行
                csv.AppendLine("起因,機能名,ページ数,ファイル数,先週まで完了数,今週着手数,今週完了数,来週着手数,来週完了数,最小開始日,最大終了日");

                foreach (var item in results)
                {

                    csv.AppendLine(
                        $"{item.KeyNo},{item.FunctionName},{item.TotalPageCount},{item.TotalCount},{item.LastWeekCount}," +
                        $"{item.ThisWeekStartCount},{item.ThisWeekEndCount},{item.NextWeekStartCount},{item.NextWeekEndCount},{item.MinStartTime.ToString()},{item.MaxEndTime.ToString()}"
                    );
                }

                File.WriteAllText(saveDialog.FileName, csv.ToString(), Encoding.UTF8);
                UpdateStatus(statusCallback, $"统计结果已导出到: {saveDialog.FileName}");
                return true;
            }
            catch (Exception ex)
            {
                UpdateStatus(statusCallback, $"导出CSV时出错: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// 尝试解析日期时间字符串
        /// </summary>
        /// <param name="dateText">日期字符串</param>
        /// <returns>解析后的日期时间，无法解析返回null</returns>
        private DateTime? ParseDateTime(string dateText)
        {
            if (string.IsNullOrWhiteSpace(dateText))
                return null;

            if (DateTime.TryParse(dateText, out DateTime date))
                return date;

            return null;
        }

        /// <summary>
        /// 更新状态回调
        /// </summary>
        private void UpdateStatus(Action<string> statusCallback, string message)
        {
            statusCallback?.Invoke(message);
        }
    }
}