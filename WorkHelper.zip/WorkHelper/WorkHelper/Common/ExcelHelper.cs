﻿using Microsoft.Office.Interop.Excel;
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using WorkHelper.Common;
using Range = Microsoft.Office.Interop.Excel.Range;

namespace WorkHelper.Common
{
    public partial class ExcelHelper : IDisposable
    {
        private Application excelApp = null;
        private Workbook workbook = null;
        private Worksheet worksheet = null;
        private string tempFilePath = null;  // 用于跟踪临时文件

        // 普通打开方式（显示界面）
        public bool OpenExcel(string filePath)
        {
            try
            {
                excelApp = new Application();
                excelApp.Visible = true;
                workbook = excelApp.Workbooks.Open(filePath);
                worksheet = workbook.ActiveSheet;
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"打开Excel出错: {ex.Message}");
                CleanUp();
                return false;
            }
        }

        // 隐式只读方式打开
        public bool OpenExcelSilently(string filePath, bool readOnly = true)
        {
            try
            {
                excelApp = new Application
                {
                    Visible = false,
                    DisplayAlerts = false,
                    ScreenUpdating = false,
                    EnableEvents = false
                };

                workbook = excelApp.Workbooks.Open(
                    Filename: filePath,
                    UpdateLinks: false,
                    ReadOnly: readOnly,
                    IgnoreReadOnlyRecommended: true
                );
                worksheet = workbook.ActiveSheet;

                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"隐式打开Excel出错: {ex.Message}");
                CleanUp();
                return false;
            }
        }

        // 隐式打开副本
        public bool OpenExcelSilentlyAsCopy(string filePath)
        {
            try
            {
                string tempFolder = Path.Combine(Path.GetTempPath(), "ExcelTemp");
                Directory.CreateDirectory(tempFolder);
                tempFilePath = Path.Combine(tempFolder,
                    $"{Path.GetFileNameWithoutExtension(filePath)}_{Guid.NewGuid()}{Path.GetExtension(filePath)}");

                File.Copy(filePath, tempFilePath);

                return OpenExcelSilently(tempFilePath, false);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"隐式打开Excel副本出错: {ex.Message}");
                CleanUp();
                return false;
            }
        }

        // 创建新的Excel文件 带文件名
        public bool CreateNewExcel(string savePath)
        {
            try
            {
                excelApp = new Application();
                excelApp.Visible = true;
                workbook = excelApp.Workbooks.Add();
                worksheet = workbook.ActiveSheet;

                if (!string.IsNullOrEmpty(savePath))
                {
                    workbook.SaveAs(savePath);
                }
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"创建Excel出错: {ex.Message}");
                CleanUp();
                return false;
            }
        }

        // 创建新的Excel文件
        public bool CreateNewExcel()
        {
            try
            {
                excelApp = new Application();
                excelApp.Visible = true;
                workbook = excelApp.Workbooks.Add();
                worksheet = workbook.ActiveSheet;

                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"创建Excel出错: {ex.Message}");
                CleanUp();
                return false;
            }
        }

        // 打开现有Excel文件（可选择只读模式）
        public bool OpenExcel(string filePath, bool readOnly = false)
        {
            try
            {
                excelApp = new Application();
                excelApp.Visible = true;

                // 使用UpdateLinks参数和ReadOnly参数
                workbook = excelApp.Workbooks.Open(
                    Filename: filePath,
                    UpdateLinks: false,      // 不更新链接
                    ReadOnly: readOnly,      // 是否只读
                    IgnoreReadOnlyRecommended: true  // 忽略推荐只读提示
                );

                worksheet = workbook.ActiveSheet;
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"打开Excel出错: {ex.Message}");
                CleanUp();
                return false;
            }
        }

        // 以只读方式打开Excel文件的快捷方法
        public bool OpenExcelReadOnly(string filePath)
        {
            return OpenExcel(filePath, true);
        }

        // 以副本方式打开Excel文件（不锁定源文件）
        public bool OpenExcelAsCopy(string filePath)
        {
            try
            {
                // 创建临时文件夹（如果不存在）
                string tempFolder = FileUtils.Temp.tempPath;
                Directory.CreateDirectory(tempFolder);

                // 生成临时文件路径
                tempFilePath = Path.Combine(tempFolder,
                    $"{Path.GetFileNameWithoutExtension(filePath)}_{Guid.NewGuid()}{Path.GetExtension(filePath)}");

                // 复制源文件到临时文件
                File.Copy(filePath, tempFilePath);

                // 打开临时文件
                excelApp = new Application();
                excelApp.Visible = true;
                workbook = excelApp.Workbooks.Open(tempFilePath);
                worksheet = workbook.ActiveSheet;

                FileTrackingManager.Instance.TrackFile(filePath, tempFilePath);
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"打开Excel副本出错: {ex.Message}");
                CleanUp();
                return false;
            }
        }

        // 获取当前工作簿对象（用于搜索功能）
        public Workbook GetWorkbook()
        {
            return workbook;
        }

        // 写入单元格内容
        public void WriteToCell(int row, int col, object value)
        {
            if (worksheet != null)
            {
                worksheet.Cells[row, col] = value;
            }
        }

        // 读取单元格内容
        public string ReadCell(int row, int col)
        {
            if (worksheet != null)
            {
                Range range = worksheet.Cells[row, col];
                if (range.Value2 != null)
                    return range.Value2.ToString();
            }
            return string.Empty;
        }

        // 设置单元格格式
        public void FormatCell(int row, int col, string backgroundColor = null, bool isBold = false)
        {
            if (worksheet != null)
            {
                Range range = worksheet.Cells[row, col];

                if (!string.IsNullOrEmpty(backgroundColor))
                {
                    range.Interior.Color = System.Drawing.ColorTranslator.FromHtml(backgroundColor);
                }

                if (isBold)
                {
                    range.Font.Bold = true;
                }
            }
        }

        // 合并单元格
        public void MergeCells(int startRow, int startCol, int endRow, int endCol)
        {
            if (worksheet != null)
            {
                Range range = worksheet.Range[worksheet.Cells[startRow, startCol],
                                           worksheet.Cells[endRow, endCol]];
                range.Merge();
            }
        }

        // 添加新工作表
        public void AddNewSheet(string sheetName)
        {
            if (workbook != null)
            {
                worksheet = workbook.Sheets.Add();
                if (!string.IsNullOrEmpty(sheetName))
                {
                    worksheet.Name = sheetName;
                }
            }
        }

        // 保存文档
        public void SaveDocument()
        {
            if (workbook != null)
            {
                workbook.Save();
            }
        }

        // 另存为新文档
        public void SaveAs(string newPath)
        {
            if (workbook != null)
            {
                workbook.SaveAs(newPath);
            }
        }

        // 关闭文档和应用程序
        public void CleanUp()
        {
            if (worksheet != null)
            {
                Marshal.ReleaseComObject(worksheet);
                worksheet = null;
            }

            if (workbook != null)
            {
                workbook.Close(SaveChanges: false);
                Marshal.ReleaseComObject(workbook);
                workbook = null;
            }

            if (excelApp != null)
            {
                excelApp.Quit();
                Marshal.ReleaseComObject(excelApp);
                excelApp = null;
            }

            // 删除临时文件
            if (tempFilePath != null && File.Exists(tempFilePath))
            {
                try
                {
                    File.Delete(tempFilePath);
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"删除临时文件出错: {ex.Message}");
                }
            }

            GC.Collect();
            GC.WaitForPendingFinalizers();
        }

        // 自动调整列宽
        public void AutoFitColumns()
        {
            if (worksheet != null)
            {
                worksheet.Columns.AutoFit();
            }
        }

        public Worksheet GetWorksheet()
        {
            return worksheet;
        }

        public void AutoFitRows()
        {
            if (worksheet != null)
            {
                worksheet.Rows.AutoFit();
            }
        }

        private bool disposed = false;

        // 实现 IDisposable 接口
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    CleanUp();
                }
                disposed = true;
            }
        }

        ~ExcelHelper()
        {
            Dispose(false);
        }

        public int GetTotalPages()
        {
            if (workbook == null) return 0;

            int totalPages = 0;

            foreach (Worksheet sheet in workbook.Worksheets)
            {
                try
                {
                    var pageSetup = sheet.PageSetup;

                    // 检查打印区域是否被设置
                    Range? printArea = null;
                    if (!string.IsNullOrEmpty(pageSetup.PrintArea))
                    {
                        printArea = sheet.Range[pageSetup.PrintArea];
                    }
                    else
                    {
                        // 如果没有设置打印区域，使用已使用区域
                        printArea = sheet.UsedRange;
                    }

                    // 获取页数
                    var pages = pageSetup.Pages;
                    if (pages != null)
                    {
                        totalPages += pages.Count;
                    }
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"获取工作表页数时出错: {ex.Message}");
                    return 0;
                }
            }

            return totalPages;
        }


        public class SheetContent
        {
            public int SheetIndex { get; set; }
            public string SheetName { get; set; }
            public string Content { get; set; }
        }

        public List<SheetContent> GetDocumentContent()
        {
            var sheets = new List<SheetContent>();
            if (workbook == null) return sheets;

            try
            {
                foreach (Worksheet sheet in workbook.Worksheets)
                {
                    // 获取使用范围
                    Range usedRange = sheet.UsedRange;
                    if (usedRange == null) continue;

                    var content = new StringBuilder();

                    // 获取行列范围
                    int rowCount = usedRange.Rows.Count;
                    int colCount = usedRange.Columns.Count;

                    // 按行读取内容
                    for (int row = 1; row <= rowCount; row++)
                    {
                        for (int col = 1; col <= colCount; col++)
                        {
                            Range cell = usedRange.Cells[row, col];
                            if (cell != null && cell.Value2 != null)
                            {
                                // 添加单元格内容
                                content.Append(cell.Value2.ToString());
                                content.Append(" "); // 单元格之间添加空格
                            }
                        }
                        // 行之间添加换行符
                        content.AppendLine();  // 为什么这个appendLine不行？
                    }

                    sheets.Add(new SheetContent
                    {
                        SheetIndex = sheet.Index,
                        SheetName = sheet.Name,
                        Content = CleanContent(content.ToString())
                    });
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"获取Excel文档内容时出错: {ex.Message}");
            }

            return sheets;
        }

        private string CleanContent(string content)
        {
            if (string.IsNullOrEmpty(content)) return string.Empty;

            // 清理特殊字符和多余的空白
            return content
                .Replace("\t", " ")
                .Trim()
                // 将多个空格替换为单个空格
                .Replace("  ", " ");
        }
    }
}