﻿using Microsoft.Office.Interop.Excel;
using Microsoft.Office.Interop.Word;
using System.Diagnostics;
using System.IO;
using System.Reflection.Emit;
using System.Xml.Linq;
using Excel = Microsoft.Office.Interop.Excel;
using Word = Microsoft.Office.Interop.Word;

namespace WorkHelper.Common
{
    public class CommentInfo
    {
        public bool IsResolved {  get; set; }
        public string FileName { get; set; }
        public string Location { get; set; }        // Sheet名/大纲标题
        public string Position { get; set; }        // 单元格位置/页数
        public string TargetContent { get; set; }   // 被评论的内容
        public string Content { get; set; }
        public string Author { get; set; }
        public DateTime? Time { get; set; }
        public string Replies { get; set; }         // 格式化的回复信息
        public string FullPath { get; set; }    // 相对路径

        public int SheetCount { get; set; }       // Page Sheet数量

        public string MakeOutputComment ()
        {
            string cell = string.Empty;
            if(!String.IsNullOrEmpty(TargetContent))
            {
                cell = "【セル内容】： \n" + TargetContent + "\n";
            }

            if (!String.IsNullOrEmpty(Content))
            {
                Content = "\n【指摘】： \n" + Content ;
            }

            return cell + Content;
        }
    }

    // Excel Helper 中添加的方法
    public partial class ExcelHelper
    {
        public List<CommentInfo> GetAllComments(string filePath)
        {
            var comments = new List<CommentInfo>();
            try
            {
                if (workbook == null || worksheet == null) return comments;

                string fileName = Path.GetFileName(filePath);
                string basePath = Path.GetDirectoryName(filePath);


                foreach (Worksheet sheet in workbook.Worksheets)
                {
                    // 获取传统注释
                    //GetLegacyComments(sheet, fileName, basePath, comments);

                    // 获取新版批注
                    GetModernComments(sheet, fileName, basePath, comments);
                }

                // get count of sheets
                int sheetCount = workbook.Sheets.Count;

                // put sheet count to each comment
                foreach (var comment in comments)
                {
                    comment.SheetCount = sheetCount;
                }

                if (comments.Count == 0)
                {
                    var commentInfo = new CommentInfo
                    {
                        FileName = fileName,
                        FullPath = Path.GetFullPath(filePath),
                        SheetCount = sheetCount,
                    };
                    comments.Add(commentInfo);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"获取Excel评论时出错: {ex.Message}");
            }
            return comments;
        }

        private void GetLegacyComments(Worksheet sheet, string fileName, string basePath, List<CommentInfo> comments)
        {
            try
            {
                var legacyComments = sheet.Comments;
                if (legacyComments != null)
                {
                    foreach (Excel.Comment comment in legacyComments)
                    {
                        var commentInfo = new CommentInfo
                        {
                            FileName = fileName,
                            Location = sheet.Name,
                            Position = comment.Parent.Address,
                            //CellContent = comment.Text(Text)
                            Content = comment.Text(),
                            Author = comment.Author,
                            Time = null,  // 传统注释没有时间信息
                            Replies = "",  // 传统注释没有回复功能
                            FullPath = Path.GetFullPath(Path.Combine(basePath, fileName))
                        };
                        comments.Add(commentInfo);
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"获取传统注释时出错: {ex.Message}");
            }
        }

        private void GetModernComments(Worksheet sheet, string fileName, string basePath, List<CommentInfo> comments)
        {
            try
            {
                // 使用 CommentsThreaded 属性获取新版批注
                var modernComments = sheet.CommentsThreaded;
                if (modernComments != null)
                {
                    foreach (Excel.CommentThreaded comment in modernComments)
                    {
                        // 获取评论所在单元格的内容
                        string targetContent = string.Empty;
                        try
                        {
                            Excel.Range targetCell = comment.Parent;
                            targetContent = Convert.ToString(targetCell.Text);
                        }
                        catch (Exception ex)
                        {
                            Debug.WriteLine($"获取目标单元格内容时出错: {ex.Message}");
                        }


                        var replies = new List<string>();

                        // 获取回复
                        if (comment.Replies != null)
                        {
                            foreach (Excel.CommentThreaded reply in comment.Replies)
                            {
                                replies.Add($"回复者: {reply.Author.Name}\n" +
                                          $"内容: {reply.Text()}\n" +
                                          $"时间: {reply.Date:yyyy-MM-dd HH:mm:ss}");
                            }
                        }

                        string strtest = comment.Text();
                        var commentInfo = new CommentInfo
                        {
                            // 设置文件名（当前批注所在文件的名称）
                            FileName = fileName, // 文件名，例如："example.xlsx"

                            // 设置批注所在的工作表名称
                            Location = sheet.Name, // 工作表名称，例如："Sheet1"

                            // 设置批注的位置（获取批注父对象的地址）
                            Position = comment.Parent.Address, // 批注所在的单元格地址，例如："A1"

                            TargetContent = targetContent,
                            // 设置批注的内容
                            Content = comment.Text(), // 批注的文本内容，例如："这是一个示例批注。"

                            // 设置批注的作者
                            Author = comment.Author.Name, // 批注作者的名称，例如："张三"

                            // 设置批注的时间（创建或最后修改时间）
                            Time = comment.Date, // 批注时间，例如："2024-12-03 10:00"

                            IsResolved = comment.Resolved,

                            // 设置批注的所有回复，将多个回复合并为一个字符串
                            Replies = string.Join("\n---\n", replies),
                            // 使用 "\n---\n" 分隔每个回复，例如：
                            // "回复1\n---
                            // 回复2\n---
                            // 回复3"

                            // 设置
                            FullPath = Path.GetFullPath(Path.Combine(basePath, fileName))
                            // 通过基准路径（basePath）和文件名（fileName）计算出相对路径
                            // 示例：
                            // basePath: "C:\Documents"
                            // fileName: "Projects\example.xlsx"
                            // 结果: "Projects\example.xlsx"

                        };
                        comments.Add(commentInfo);
                    }
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"获取新版批注时出错: {ex.Message}");
            }
        }

        private string GetRelativePath(string fullPath, string basePath)
        {
            try
            {
                return Path.GetRelativePath(basePath, fullPath);
            }
            catch
            {
                return fullPath;
            }
        }
    }

    // Word Helper 中添加的方法
    public partial class WordHelper
    {
        public List<CommentInfo> GetAllComments(string filePath)
        {
            var comments = new List<CommentInfo>();
            try
            {
                if (wordDoc == null) return comments;

                string fileName = Path.GetFileName(filePath);
                string basePath = Path.GetDirectoryName(filePath);

                foreach (Word.Comment comment in wordDoc.Comments)
                {
                    // 获取被评论的文本内容
                    string targetContent = string.Empty;
                    try
                    {
                        // 获取评论范围的文本
                        targetContent = comment.Scope.Text;
                    }
                    catch (Exception ex)
                    {
                        Debug.WriteLine($"获取评论目标内容时出错: {ex.Message}");
                    }

                    if (comment.Ancestor != null)
                        continue;

                    var commentInfo = new CommentInfo
                    {
                        FileName = fileName,
                        Location = GetCommentHeading(comment),
                        Position = $"Page {GetCommentPage(comment)}",
                        TargetContent = targetContent,
                        Content = comment.Range.Text,
                        Author = comment.Author,
                        Time = GetCommentDateTime(comment),
                        Replies = GetCommentReplies(comment),
                        FullPath = Path.GetFullPath(filePath),
                        IsResolved = comment.Done,
                        // 使用 Path.GetFullPath 方法将 filePath 转换为绝对路径
                    };
                    comments.Add(commentInfo);
                }

                // get page count
                int pageCount = wordDoc.ComputeStatistics(WdStatistic.wdStatisticPages);

                // put page count to each comment
                foreach (var comment in comments)
                {
                    comment.SheetCount = pageCount;
                }

                if(comments.Count == 0)
                {
                    var commentInfo = new CommentInfo
                    {
                        FileName = fileName,
                        FullPath = Path.GetFullPath(filePath),
                        SheetCount = pageCount,
                    };
                    comments.Add(commentInfo);
                }
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"获取Word评论时出错: {ex.Message}");
            }
            return comments;
        }

        private string GetCommentHeading(Word.Comment comment)
        {
            try
            {
                // 获取评论所在段落
                Paragraph para = comment.Scope.Paragraphs.First;

                // 向上查找最近的标题
                while (para != null)
                {
                    if ((int)para.OutlineLevel >= 1 && (int)para.OutlineLevel <= 9)
                    {
                        return para.Range.Text.Trim();
                    }
                    para = para.Previous();
                }
            }
            catch { }
            return string.Empty;
        }

        private int GetCommentPage(Word.Comment comment)
        {
            try
            {
                return (int)comment.Scope.get_Information(WdInformation.wdActiveEndPageNumber);
            }
            catch
            {
                return 0;
            }
        }

        private DateTime? GetCommentDateTime(Word.Comment comment)
        {
            try
            {
                return comment.Date;
            }
            catch
            {
                return null;
            }
        }

        private string GetCommentReplies(Word.Comment comment)
        {
            var replies = new List<string>();
            try
            {
                foreach (Word.Comment reply in comment.Replies)
                {
                    if (reply.Ancestor == null)
                        continue;

                    if (reply.Ancestor.Index == comment.Index)
                    {
                        replies.Add($"回复者: {reply.Author}\n" +
                              $"内容: {reply.Range.Text}\n" +
                              $"时间: {reply.Date.ToString()}");
                    }
                }
            }
            catch { }
            return string.Join("\n---\n", replies);
        }

        private string GetRelativePath(string fullPath, string basePath)
        {
            try
            {
                return Path.GetRelativePath(basePath, fullPath);
            }
            catch
            {
                return fullPath;
            }
        }
    }

    // 评论导出类
    public class CommentExporter
    {
        private readonly ExcelHelper _excelHelper;

        public CommentExporter()
        {
            _excelHelper = new ExcelHelper();
        }

        public void ExportComments(List<CommentInfo> comments)
        {
            try
            {
                if (_excelHelper.CreateNewExcel())
                {
                    // 写入表头 
                    // No.	"レビュー
                    // 依頼日"	レビューイ	レビュー対象物	"レビュー対象箇所
                    // （ページ／シート）"	チケット番号	ステータス	"レビュー日付
                    // （初回）"	レビュアー	指摘分類	指摘内容
                    // 上記通りヘッダーを設定する。
                    string[] headers = {
                    "No.", "レビュー依頼日", "レビューイ", "レビュー対象物（集計用）",
                    "レビュー対象物", "レビュー対象箇所（ページ／シート）", "チケット番号", "ステータス",
                    "レビュー日付（初回）", "レビュアー","指摘分類", "指摘内容",　"解決状態", "reply"
                };

                    for (int i = 0; i < headers.Length; i++)
                    {
                        _excelHelper.WriteToCell(1, i + 1, headers[i]);
                        _excelHelper.FormatCell(1, i + 1, "#CCCCCC", true);
                    }

                    // 写入数据
                    int row = 2;
                    foreach (var comment in comments)
                    {
                        // No.
                        _excelHelper.WriteToCell(row, 1, row -1); 
                        // レビュー依頼日
                        _excelHelper.WriteToCell(row, 2, comment.Time?.ToString() ?? "");
                        // レビューイ
                        _excelHelper.WriteToCell(row, 3, "");
                        // レビュー対象物（集計用）
                        _excelHelper.WriteToCell(row, 4, "");
                        // レビュー対象物
                        _excelHelper.WriteToCell(row, 5, comment.FileName);
                        // レビュー対象箇所（ページ／シート）
                        _excelHelper.WriteToCell(row, 6, "");
                        // チケット番号
                        _excelHelper.WriteToCell(row, 7, "");
                        // ステータス
                        _excelHelper.WriteToCell(row, 8, "新規");
                        // レビュー日付（初回）
                        _excelHelper.WriteToCell(row, 9, comment.Time?.ToString() ?? "");
                        // レビュアー
                        _excelHelper.WriteToCell(row, 10, comment.Author);
                        // 指摘分類
                        _excelHelper.WriteToCell(row, 11, "");
                        // 指摘内容 コメントされたセルに内容がある場合は　セル内容　＋　コメント内容　とする
                        _excelHelper.WriteToCell(row, 12, comment.MakeOutputComment());
                        // ステータス
                        _excelHelper.WriteToCell(row, 13, ((comment.IsResolved) ? "已解决":"未解决"));
                        // reply 返信内容
                        _excelHelper.WriteToCell(row, 14, comment.Replies);
                        row++;
                    }

                    // 自动调整列宽
                    _excelHelper.AutoFitColumns();

                    _excelHelper.GetWorksheet().Columns[12].ColumnWidth = 30;  // 设置为30个字符宽

                    // Excel列宽单位约等于一个标准字符的宽度
                    _excelHelper.GetWorksheet().Columns[14].ColumnWidth = 50;  // 设置为50个字符宽

                    _excelHelper.AutoFitRows();

                    //_excelHelper.SaveDocument();
                }
            }
            finally
            {
                //_excelHelper.CleanUp();
                // todo 
            }
        }
    }
}
