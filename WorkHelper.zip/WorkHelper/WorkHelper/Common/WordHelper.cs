﻿using Microsoft.Office.Interop.Word;
using System;
using System.Diagnostics;
using System.IO;
using System.Runtime.InteropServices;
using WorkHelper.Common;
using Range = Microsoft.Office.Interop.Word.Range;

namespace WorkHelper.Common
{
     public partial class WordHelper : IDisposable
    {
        private Application wordApp = null;
        private Document wordDoc = null;
        private string tempFilePath = null;  // 用于跟踪临时文件

        // 新建 Word 文档
        public bool CreateNewDocument(string savePath)
        {
            try
            {
                wordApp = new Application();
                wordApp.Visible = true;
                wordDoc = wordApp.Documents.Add();

                if (!string.IsNullOrEmpty(savePath))
                {
                    wordDoc.SaveAs2(savePath);
                }

                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"创建文档出错: {ex.Message}");
                CleanUp();
                return false;
            }
        }

        // 打开现有 Word 文档（可选择只读模式）
        public bool OpenDocument(string filePath, bool readOnly = false)
        {
            try
            {
                wordApp = new Application();
                wordApp.Visible = true;

                // 设置打开参数
                object fileName = filePath;
                object confirmConversions = false;
                object readOnlyParam = readOnly;
                object addToRecentFiles = false;
                object passwordDoc = Type.Missing;
                object passwordTemplate = Type.Missing;
                object revert = false;

                // 打开文档
                wordDoc = wordApp.Documents.Open(
                    ref fileName,
                    ref confirmConversions,
                    ref readOnlyParam,
                    ref addToRecentFiles,
                    ref passwordDoc,
                    ref passwordTemplate,
                    ref revert
                );

                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"打开文档出错: {ex.Message}");
                CleanUp();
                return false;
            }
        }

        // 以只读方式打开Word文档的快捷方法
        public bool OpenDocumentReadOnly(string filePath)
        {
            return OpenDocument(filePath, true);
        }

        // 以副本方式打开Word文件（不锁定源文件）
        public bool OpenDocumentAsCopy(string filePath)
        {
            try
            {
                // 创建临时文件夹（如果不存在）
                string tempFolder = FileUtils.Temp.tempPath;
                Directory.CreateDirectory(tempFolder);

                // 生成临时文件路径
                tempFilePath = Path.Combine(tempFolder,
                    $"{Path.GetFileNameWithoutExtension(filePath)}_{Guid.NewGuid()}{Path.GetExtension(filePath)}");

                // 复制源文件到临时文件
                File.Copy(filePath, tempFilePath);

                // 打开临时文件
                wordApp = new Application();
                wordApp.Visible = true;

                object fileName = tempFilePath;
                object readOnly = false;
                object isVisible = true;

                wordDoc = wordApp.Documents.Open(
                    ref fileName,
                    ReadOnly: ref readOnly,
                    Visible: ref isVisible
                );

                FileTrackingManager.Instance.TrackFile(filePath, tempFilePath);
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"打开Word副本出错: {ex.Message}");
                CleanUp();
                return false;
            }
        }

        // 普通打开方式（显示界面）
        public bool OpenDocument(string filePath)
        {
            try
            {
                wordApp = new Application();
                wordApp.Visible = true;

                wordDoc = wordApp.Documents.Open(filePath);
                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"打开Word文档出错: {ex.Message}");
                CleanUp();
                return false;
            }
        }

        // 隐式只读方式打开
        public bool OpenDocumentSilently(string filePath, bool readOnly = true)
        {
            try
            {
                wordApp = new Application
                {
                    Visible = false,
                    DisplayAlerts = WdAlertLevel.wdAlertsNone
                };

                object fileName = filePath;
                object readOnlyParam = readOnly;
                object isVisible = false;
                object missing = System.Reflection.Missing.Value;

                wordDoc = wordApp.Documents.Open(
                    ref fileName,
                    ref missing, ref readOnlyParam,
                    ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref missing,
                    ref missing, ref missing, ref isVisible,
                    ref missing, ref missing, ref missing,
                    ref missing
                );

                return true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"隐式打开Word文档出错: {ex.Message}");
                CleanUp();
                return false;
            }
        }

        // 隐式打开副本
        public bool OpenDocumentSilentlyAsCopy(string filePath)
        {
            try
            {
                string tempFolder = Path.Combine(Path.GetTempPath(), "WordTemp");
                Directory.CreateDirectory(tempFolder);
                tempFilePath = Path.Combine(tempFolder,
                    $"{Path.GetFileNameWithoutExtension(filePath)}_{Guid.NewGuid()}{Path.GetExtension(filePath)}");

                File.Copy(filePath, tempFilePath);

                return OpenDocumentSilently(tempFilePath, false);
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"隐式打开Word副本出错: {ex.Message}");
                CleanUp();
                return false;
            }
        }

        // 获取当前文档对象（用于搜索功能）
        public Document GetDocument()
        {
            return wordDoc;
        }

        // 向文档添加内容
        public void AddContent(string content)
        {
            if (wordDoc != null)
            {
                object missing = System.Reflection.Missing.Value;
                object collapse = WdCollapseDirection.wdCollapseEnd;
                wordDoc.Content.Collapse(ref collapse);

                wordDoc.Content.InsertAfter(content + "\n");
            }
        }

        // 保存文档
        public void SaveDocument()
        {
            if (wordDoc != null)
            {
                wordDoc.Save();
            }
        }

        // 另存为新文档
        public void SaveAs(string newPath)
        {
            if (wordDoc != null)
            {
                wordDoc.SaveAs2(newPath);
            }
        }

        // 关闭文档和应用程序
        public void CleanUp()
        {
            if (wordDoc != null)
            {
                wordDoc.Close(SaveChanges: false);
                Marshal.ReleaseComObject(wordDoc);
                wordDoc = null;
            }

            if (wordApp != null)
            {
                wordApp.Quit();
                Marshal.ReleaseComObject(wordApp);
                wordApp = null;
            }

            // 删除临时文件
            if (tempFilePath != null && File.Exists(tempFilePath))
            {
                try
                {
                    File.Delete(tempFilePath);
                }
                catch (Exception ex)
                {
                    Debug.WriteLine($"删除临时文件出错: {ex.Message}");
                }
            }

            GC.Collect();
            GC.WaitForPendingFinalizers();
        }

        public class PageContent
        {
            public int PageNumber { get; set; }
            public string Content { get; set; }
        }

        public List<PageContent> GetDocumentContent()
        {
            if (wordDoc == null)
                return new List<PageContent>();

            wordDoc.Repaginate();
            int totalPages = wordDoc.ComputeStatistics(WdStatistic.wdStatisticPages, false);

            List<PageContent> results = new List<PageContent>();

            // 整个文档范围
            Range docRange = wordDoc.Content;
            docRange.Collapse(WdCollapseDirection.wdCollapseStart);

            object missing = Type.Missing;

            for (int page = 1; page <= totalPages; page++)
            {
                int pageStartPos = docRange.Start;

                // 不断往后移动 end，让 Range 覆盖整页
                while (docRange.Information[WdInformation.wdActiveEndPageNumber] == page
                       && docRange.End < wordDoc.Content.End)
                {
                    // 一次移动 1 字符，可根据需要调整步长（或先大步后小步）
                    docRange.MoveEnd(WdUnits.wdCharacter, 1);
                }

                // 当前 page 的 Range 就是 [pageStartPos, docRange.End)
                int pageEndPos = docRange.End;

                // 记录当前页的文字
                string text = wordDoc.Range(pageStartPos, pageEndPos).Text;
                results.Add(new PageContent
                {
                    PageNumber = page,
                    Content = text
                });

                // 把 Range 折叠到末尾，准备处理下一页
                docRange.SetRange(pageEndPos, pageEndPos);
            }

            return results;
        }

        private string CleanContent(string content)
        {
            if (string.IsNullOrEmpty(content)) return string.Empty;

            // 清理特殊字符和多余的空白
            return content
                .Replace("\r", " ")
                .Replace("\n", " ")
                .Replace("\t", " ")
                .Replace("\v", " ")
                .Replace("\f", " ")
                .Replace("\u0007", "") // 删除控制字符
                .Replace("\u000b", "") // 删除垂直制表符
                .Trim();
        }

        private bool disposed = false;

        // 实现 IDisposable 接口
        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        protected virtual void Dispose(bool disposing)
        {
            if (!disposed)
            {
                if (disposing)
                {
                    CleanUp();
                }
                disposed = true;
            }
        }

        ~WordHelper()
        {
            Dispose(false);
        }
    }
}