﻿using System;
using System.Collections.Generic;
using System.Data.SQLite;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WorkHelper.Common
{

public class DocumentIndexer
    {
        private readonly string _connectionString = @"Data Source=C:\work\sqlitedb.db;Version=3;";

        public async Task IndexDirectory(string directoryPath)
        {
            using var connection = new SQLiteConnection(_connectionString);
            await connection.OpenAsync();

            // 遍历目录下所有文件
            foreach (var file in Directory.GetFiles(directoryPath, "*.*", SearchOption.AllDirectories))
            {
                if (OfficeManager.IsWordFile(file))
                {
                    await IndexWordDocument(connection, file);
                }
                else if (OfficeManager.IsExcelFile(file))
                {
                    await IndexExcelDocument(connection, file);
                }
            }
        }

        private async Task IndexWordDocument(SQLiteConnection connection, string filePath)
        {
            var wordHelper = OfficeManager.Instance.CreateWordHelper();
            try
            {
                if (wordHelper.OpenDocumentSilently(filePath))
                {
                    // 插入文档记录
                    int docId = await InsertDocument(connection, filePath, "WORD");

                    // 获取并存储文档内容
                    var pages = wordHelper.GetDocumentContent();
                    foreach (var page in pages)
                    {
                        await InsertPage(connection, docId, page.PageNumber, page.Content, $"{page.PageNumber}");
                    }
                }
            }
            finally
            {
                wordHelper.CleanUp();
            }
        }

        private async Task IndexExcelDocument(SQLiteConnection connection, string filePath)
        {
            var excelHelper = new ExcelHelper();
            try
            {
                if (excelHelper.OpenExcelSilently(filePath))
                {
                    // 插入文档记录
                    int docId = await InsertDocument(connection, filePath, "EXCEL");

                    // 获取并存储文档内容
                    var sheets = excelHelper.GetDocumentContent();
                    foreach (var sheet in sheets)
                    {
                        await InsertPage(connection, docId, sheet.SheetIndex,
                            sheet.Content, $"{sheet.SheetName}");
                    }
                }
            }
            finally
            {
                excelHelper.CleanUp();
            }
        }

        private async Task<int> InsertDocument(SQLiteConnection connection, string filePath, string fileType)
        {
            // 首先检查文档是否已存在
            const string checkSql = @"
        SELECT id FROM Documents 
        WHERE file_path = @filePath";

            using (var checkCmd = new SQLiteCommand(checkSql, connection))
            {
                checkCmd.Parameters.AddWithValue("@filePath", filePath);
                var existingId = await checkCmd.ExecuteScalarAsync();
                if (existingId != null)
                {
                    return Convert.ToInt32(existingId);
                }
            }

            // 插入新文档记录
            const string insertSql = @"
        INSERT INTO Documents (file_path, file_name, file_type)
        VALUES (@filePath, @fileName, @fileType);
        SELECT last_insert_rowid();";

            using (var cmd = new SQLiteCommand(insertSql, connection))
            {
                cmd.Parameters.AddWithValue("@filePath", filePath);
                cmd.Parameters.AddWithValue("@fileName", Path.GetFileName(filePath));
                cmd.Parameters.AddWithValue("@fileType", fileType);

                return Convert.ToInt32(await cmd.ExecuteScalarAsync());
            }
        }

        private async Task InsertPage(SQLiteConnection connection, int documentId, int pageNumber, string content, string location)
        {
            using var transaction = connection.BeginTransaction();
            try
            {
                // 1. 从主表删除并插入新数据
                const string upsertMainSql = @"
            INSERT OR REPLACE INTO DocumentPages (document_id, page_number, content, location)
            VALUES (@documentId, @pageNumber, @content, @location);";

                using (var cmd = new SQLiteCommand(upsertMainSql, connection))
                {
                    cmd.Parameters.AddWithValue("@documentId", documentId);
                    cmd.Parameters.AddWithValue("@pageNumber", pageNumber);
                    cmd.Parameters.AddWithValue("@content", content ?? string.Empty);
                    cmd.Parameters.AddWithValue("@location", location);
                    await cmd.ExecuteNonQueryAsync();
                }

            //    // 2. 重建 FTS 表内容
            //    const string rebuildFtsSql = @"
            //INSERT OR REPLACE INTO DocumentPages_fts(content, location, document_id, page_number)
            //SELECT content, location, document_id, page_number 
            //FROM DocumentPages;";

            //    using (var cmd = new SQLiteCommand(rebuildFtsSql, connection))
            //    {
            //        await cmd.ExecuteNonQueryAsync();
            //    }

                transaction.Commit();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"插入出错: {ex.Message}");
                transaction.Rollback();
                throw;
            }
        }
    }

}
