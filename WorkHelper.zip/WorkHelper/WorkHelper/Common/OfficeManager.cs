﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Windows;
using WorkHelper.Common;

public class OfficeManager : IDisposable
{
    private static OfficeManager _instance;
    private static readonly object _lock = new object();

    private List<ExcelHelper> excelInstances;
    private List<WordHelper> wordInstances;
    private bool disposed = false;

    private OfficeManager()
    {
        excelInstances = new List<ExcelHelper>();
        wordInstances = new List<WordHelper>();

        // 注册WPF应用程序退出事件
        Application.Current.Exit += OnApplicationExit;

        // 注册应用程序域卸载事件
        AppDomain.CurrentDomain.ProcessExit += OnProcessExit;
        AppDomain.CurrentDomain.DomainUnload += OnDomainUnload;
    }

    public static OfficeManager Instance
    {
        get
        {
            if (_instance == null)
            {
                lock (_lock)
                {
                    if (_instance == null)
                    {
                        _instance = new OfficeManager();
                    }
                }
            }
            return _instance;
        }
    }

    // 创建并注册Excel实例
    public ExcelHelper CreateExcelHelper()
    {
        var excel = new ExcelHelper();
        excelInstances.Add(excel);
        return excel;
    }

    // 创建并注册Word实例
    public WordHelper CreateWordHelper()
    {
        var word = new WordHelper();
        wordInstances.Add(word);
        return word;
    }

    public static bool IsExcelFile(string strFileName)
    {
        return strFileName.EndsWith(".xls") || strFileName.EndsWith(".xlsx") || strFileName.EndsWith(".XLS") || strFileName.EndsWith(".XLSX") || strFileName.EndsWith(".xlsm");
    }

    public static bool IsWordFile(string strFileName)
    {
        return strFileName.EndsWith(".doc") || strFileName.EndsWith(".docx") || strFileName.EndsWith(".DOC") || strFileName.EndsWith(".DOCX");
    }

    // 释放特定的Excel实例
    public void ReleaseExcelHelper(ExcelHelper excel)
    {
        if (excel != null)
        {
            try
            {
                excel.CleanUp();
                excelInstances.Remove(excel);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"释放Excel实例时出错: {ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }

    // 释放特定的Word实例
    public void ReleaseWordHelper(WordHelper word)
    {
        if (word != null)
        {
            try
            {
                word.CleanUp();
                wordInstances.Remove(word);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"释放Word实例时出错: {ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }
    }

    // 清理所有Office实例
    private void CleanUpAllInstances()
    {
        foreach (var excel in excelInstances.ToArray())
        {
            try
            {
                excel.CleanUp();
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"清理Excel实例时出错: {ex.Message}");
            }
        }
        excelInstances.Clear();

        foreach (var word in wordInstances.ToArray())
        {
            try
            {
                word.CleanUp();
            }
            catch (Exception ex)
            {
                Debug.WriteLine($"清理Word实例时出错: {ex.Message}");
            }
        }
        wordInstances.Clear();
    }

    private void OnApplicationExit(object sender, ExitEventArgs e)
    {
        Dispose();
    }

    private void OnProcessExit(object sender, EventArgs e)
    {
        Dispose();
    }

    private void OnDomainUnload(object sender, EventArgs e)
    {
        Dispose();
    }

    public void Dispose()
    {
        Dispose(true);
        GC.SuppressFinalize(this);
    }

    protected virtual void Dispose(bool disposing)
    {
        if (!disposed)
        {
            if (disposing)
            {
                CleanUpAllInstances();
            }
            disposed = true;
        }
    }

    ~OfficeManager()
    {
        Dispose(false);
    }
}