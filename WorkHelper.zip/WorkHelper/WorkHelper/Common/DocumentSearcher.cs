﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text.RegularExpressions;
using Microsoft.Office.Interop.Word;
using Microsoft.Office.Interop.Excel;
using Range = Microsoft.Office.Interop.Excel.Range;
using Word = Microsoft.Office.Interop.Word;
using System.Collections.Concurrent;
using System.Threading;

public class SearchResult
{
    public string FileName { get; set; }
    public string FilePath { get; set; }
    public string FileType { get; set; }
    public string Location { get; set; }
    public string Context { get; set; }
    public int PageNumber { get; set; }
    public string Keyword { get; set; }
    public int StartPosition { get; set; }  // Word文档中的起始位置
    public string SheetName { get; set; }   // Excel工作表名
    public string CellAddress { get; set; } // Excel单元格地址
}

public class DocumentSearcher
{
    private readonly OfficeManager _officeManager;
    private List<SearchResult> _searchResults;

    public List<SearchResult> SearchResults { get => _searchResults; set => _searchResults = value; }

    public DocumentSearcher()
    {
        _officeManager = OfficeManager.Instance;
        SearchResults = new List<SearchResult>();
    }

    public void SearchInDirectory(string directoryPath, string keyword)
    {
        SearchResults.Clear();
        var files = Directory.GetFiles(directoryPath, "*.*", SearchOption.AllDirectories)
            .Where(f => OfficeManager.IsExcelFile(f)|| OfficeManager.IsWordFile(f));

        foreach (var file in files)
        {
            if (OfficeManager.IsWordFile(file))
            {
                SearchInWord(file, keyword);
            }
            else if (OfficeManager.IsExcelFile(file))
            {
                SearchInExcel(file, keyword);
            }
        }
    }

    public void SearchInDirectory(string directoryPath, string keyword, Action<string> statusCallback, CancellationToken cancellationToken)
    {
        _searchResults.Clear();

        try
        {
            // 获取所有支持的文件
            var files = Directory.GetFiles(directoryPath, "*.*", SearchOption.AllDirectories)
                .Where(f => OfficeManager.IsExcelFile(f) || OfficeManager.IsWordFile(f))
                .ToList();


            statusCallback?.Invoke($"找到 {files.Count} 个文件需要搜索");
            int processedFiles = 0;

            var results = new ConcurrentBag<SearchResult>();
            var totalFiles = files.Count();

            // 使用 ParallelOptions 来控制并行度和取消
            var parallelOptions = new ParallelOptions
            {
                MaxDegreeOfParallelism = 4, // 限制并行数量
                CancellationToken = cancellationToken
            };


            Parallel.ForEach(files, parallelOptions, file =>
            //foreach (var file in files)

            {
                // 检查是否请求取消
                if (cancellationToken.IsCancellationRequested)
                {
                    statusCallback?.Invoke("搜索已取消");
                    return;
                }

                try
                {
                    statusCallback?.Invoke($"正在搜索: {Path.GetFileName(file)}");

                    if (OfficeManager.IsWordFile(file))
                    {
                        SearchInWord(file, keyword);
                    }
                    else if (OfficeManager.IsExcelFile(file))
                    {
                        SearchInExcel(file, keyword);
                    }

                    processedFiles++;
                    var progressPercentage = (int)((double)processedFiles / files.Count * 100);
                    statusCallback?.Invoke($"已处理 {processedFiles}/{files.Count} 个文件 ({progressPercentage}%)");
                }
                catch (Exception ex)
                {
                    statusCallback?.Invoke($"处理文件 {Path.GetFileName(file)} 时出错: {ex.Message}");
                    // 继续处理下一个文件
                    return;
                    //continue;
                }
            });
        //}

            statusCallback?.Invoke($"搜索完成！共找到 {_searchResults.Count} 个匹配项");
        }
        catch (Exception ex)
        {
            statusCallback?.Invoke($"搜索过程中发生错误: {ex.Message}");
            throw;
        }
    }
    private void SearchInWord(string filePath, string keyword)
    {
        var wordHelper = _officeManager.CreateWordHelper();
        try
        {
            if (wordHelper.OpenDocumentSilently(filePath))
            {
                var wordDoc = wordHelper.GetDocument();
                var findObject = wordDoc.Content.Find;
                findObject.ClearFormatting();
                findObject.Text = keyword;
                findObject.Forward = true;
                findObject.Wrap = WdFindWrap.wdFindStop;  // 改为 Stop 而不是 Continue
                findObject.Format = false;
                findObject.MatchCase = false;
                findObject.MatchWholeWord = false;
                findObject.MatchWildcards = false;
                findObject.MatchSoundsLike = false;
                findObject.MatchAllWordForms = false;

                // 记录第一次找到的位置
                Word.Range firstFound = null;

                while (findObject.Execute())
                {
                    // 获取当前找到的范围
                    Word.Range currentRange = findObject.Parent;

                    // 如果是第一次找到，保存位置
                    if (firstFound == null)
                    {
                        firstFound = currentRange.Duplicate;
                    }
                    // 如果找到的位置与第一次相同，说明已经搜索了一圈
                    else if (currentRange.Start == firstFound.Start)
                    {
                        break;
                    }

                    var result = new SearchResult
                    {
                        FilePath = filePath,
                        FileName = Path.GetFileName(filePath),
                        FileType = "Word",
                        Keyword = keyword,
                        StartPosition = findObject.Parent.Start,
                        PageNumber = wordDoc.Range(0, currentRange.Start).ComputeStatistics(WdStatistic.wdStatisticPages) + 1,
                        Location = $"Page {wordDoc.Range(0, currentRange.Start).ComputeStatistics(WdStatistic.wdStatisticPages) + 1}",
                        Context = GetWordContext(currentRange, 50),
                    };

                    SearchResults.Add(result);
                }
            }
        }
        finally
        {
            _officeManager.ReleaseWordHelper(wordHelper);
        }
    }

    private string GetWordContext(Word.Range range, int charactersAround)
    {
        int start = Math.Max(0, range.Start - charactersAround);
        int end = range.End + charactersAround;
        var contextRange = range.Document.Range(start, end);
        return contextRange.Text.Replace("\r", " ").Replace("\n", " ").Trim();
        //return string.Empty;
    }

    private void SearchInExcel(string filePath, string keyword)
    {
        var excelHelper = _officeManager.CreateExcelHelper();
        try
        {
            if (excelHelper.OpenExcelSilently(filePath))
            {
                var workbook = excelHelper.GetWorkbook();
                foreach (Worksheet sheet in workbook.Worksheets)
                {
                    var usedRange = sheet.UsedRange;
                    var searchRange = usedRange.Find(
                        What: keyword,
                        LookIn: XlFindLookIn.xlValues,
                        LookAt: XlLookAt.xlPart,
                        SearchOrder: XlSearchOrder.xlByRows,
                        SearchDirection: XlSearchDirection.xlNext,
                        MatchCase: false);

                    if (searchRange != null)
                    {
                        var firstAddress = searchRange.Address;
                        do
                        {
                            var result = new SearchResult
                            {
                                FilePath = filePath,
                                FileName = Path.GetFileName(filePath),
                                FileType = "Excel",
                                Keyword = keyword,
                                SheetName = sheet.Name,
                                CellAddress = searchRange.Address,
                                PageNumber = 1, // Excel默认页码
                                Location = $"Sheet: {sheet.Name}, Cell: {searchRange.Address}",
                                Context = GetExcelContext(searchRange)
                            };
                            SearchResults.Add(result);

                            searchRange = usedRange.FindNext(searchRange);
                        } while (searchRange != null && searchRange.Address != firstAddress);
                    }
                }
            }
        }
        finally
        {
            _officeManager.ReleaseExcelHelper(excelHelper);
        }
    }

    private string GetExcelContext(Range cell)
    {
        // 获取周围单元格的值
        var row = cell.Row;
        var col = cell.Column;
        var sheet = cell.Worksheet;

        var context = new List<string>();

        // 获取当前行的前后几个单元格
        for (int c = Math.Max(1, col - 25); c <= Math.Min(col + 25, sheet.UsedRange.Columns.Count); c++)
        {
            var value = sheet.Cells[row, c].Text;
            if (!string.IsNullOrEmpty(value))
                context.Add(value);
        }

        return string.Join(" | ", context);
    }

    public void ExportResultsToExcel(string outputPath)
    {
        var excelHelper = _officeManager.CreateExcelHelper();
        try
        {
            if (excelHelper.CreateNewExcel(outputPath))
            {
                // 设置表头
                string[] headers = { "文件路径", "文件类型", "关键字", "位置", "页码", "上下文" };
                for (int i = 0; i < headers.Length; i++)
                {
                    excelHelper.WriteToCell(1, i + 1, headers[i]);
                    excelHelper.FormatCell(1, i + 1, "#CCCCCC", true);
                }

                // 写入数据
                for (int i = 0; i < SearchResults.Count; i++)
                {
                    var result = SearchResults[i];
                    excelHelper.WriteToCell(i + 2, 1, result.FilePath);
                    excelHelper.WriteToCell(i + 2, 2, result.FileType);
                    excelHelper.WriteToCell(i + 2, 3, result.Keyword);
                    excelHelper.WriteToCell(i + 2, 4, result.Location);
                    excelHelper.WriteToCell(i + 2, 5, result.PageNumber);
                    excelHelper.WriteToCell(i + 2, 6, result.Context);
                }

                excelHelper.SaveDocument();
            }
        }
        finally
        {
            _officeManager.ReleaseExcelHelper(excelHelper);
        }
    }

    // 打开文件并定位到搜索结果位置
    public void OpenAndLocate(SearchResult result)
    {
        if (result.FileType == "Word")
        {
            var wordHelper = _officeManager.CreateWordHelper();
            try
            {
                if (wordHelper.OpenDocumentReadOnly(result.FilePath))
                {
                    var doc = wordHelper.GetDocument();
                    var range = doc.Range(result.StartPosition, result.StartPosition + result.Keyword.Length);
                    range.Select();
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"打开Word文档失败: {ex.Message}");
            }
        }
        else if (result.FileType == "Excel")
        {
            var excelHelper = _officeManager.CreateExcelHelper();
            try
            {
                if (excelHelper.OpenExcelReadOnly(result.FilePath))
                {
                    var workbook = excelHelper.GetWorkbook();
                    Worksheet sheet = workbook.Worksheets[result.SheetName];
                    sheet.Activate();
                    Range cell = sheet.Range[result.CellAddress];
                    cell.Select();
                }
            }
            catch (Exception ex)
            {
                throw new Exception($"打开Excel文档失败: {ex.Message}");
            }
        }
    }
}