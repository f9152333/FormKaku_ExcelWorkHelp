﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using WorkHelper.Common;


namespace WorkHelper
{
    public partial class FileAnalysisWindow : Window
    {
        private readonly OfficeManager _officeManager;
        EncodingProvider provider;

        public FileAnalysisWindow()
        {
            InitializeComponent();
            _officeManager = OfficeManager.Instance;
            provider = System.Text.CodePagesEncodingProvider.Instance;

        }

        private void BtnSelectFolder_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFolderDialog
            {
                Title = "选择文件夹"
            };

            if (dialog.ShowDialog() == true)
            {
                txtFolderPath.Text = dialog.FolderName;
            }
        }

        private void BtnSelectExcel_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
            {
                Filter = "Excel文件|*.xlsx;*.xls",
                Title = "选择Excel文件"
            };

            if (dialog.ShowDialog() == true)
            {
                txtExcelPath.Text = dialog.FileName;
            }
        }

        private async void BtnExportPages_Click(object sender, RoutedEventArgs e)
        {
            string fileList = txtTargetFilesPath.Text;
            if (string.IsNullOrWhiteSpace(txtFolderPath.Text))
            {
                MessageBox.Show("请先选择文件夹", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var saveDialog = new SaveFileDialog
            {
                Filter = "CSV文件|*.csv",
                Title = "保存页数统计",
                FileName = $"页数统计_{DateTime.Now:yyyyMMdd_HHmmss}.csv"
            };

            if (saveDialog.ShowDialog() != true) return;

            try
            {
                SetControlsState(false);
                progressBar.Visibility = Visibility.Visible;
                UpdateStatus("正在统计文件页数...");

                // 获取要处理的文件列表
                List<string> targetFiles;
                if (!string.IsNullOrWhiteSpace(fileList) && File.Exists(fileList))
                {
                    // 从文本文件读取文件名列表
                    var encoding = provider.GetEncoding("shift-jis");
                    var fileNames = File.ReadAllLines(fileList, encoding)
                        .Where(line => !string.IsNullOrWhiteSpace(line))
                        .Select(line => line.Trim())
                        .ToList();

                    // 在指定文件夹中查找这些文件
                    targetFiles = new List<string>();
                    foreach (var fileName in fileNames)
                    {
                        var foundFiles = Directory.GetFiles(txtFolderPath.Text, fileName, SearchOption.AllDirectories);
                        targetFiles.AddRange(foundFiles);
                    }
                }
                else
                {
                    // 如果没有指定文件列表，则处理所有文件
                    targetFiles = Directory.GetFiles(txtFolderPath.Text, "*.*", SearchOption.AllDirectories)
                        .Where(f => OfficeManager.IsWordFile(f) || OfficeManager.IsExcelFile(f))
                        .ToList();
                }

                UpdateStatus($"找到 {targetFiles.Count} 个文件需要处理...");

                var results = new List<(string fileName, int pageCount)>();


                foreach (var file in targetFiles)
                {
                    try
                    {
                        if (OfficeManager.IsWordFile(file))
                        {
                            using (var word = _officeManager.CreateWordHelper())
                            {
                                if (word.OpenDocumentSilently(file))
                                {
                                    var doc = word.GetDocument();
                                    int pageCount = doc.ComputeStatistics(Microsoft.Office.Interop.Word.WdStatistic.wdStatisticPages);
                                    results.Add((Path.GetFileName(file), pageCount));
                                }
                            }
                        }
                        else if (OfficeManager.IsExcelFile(file))
                        {
                            using (var excel = _officeManager.CreateExcelHelper())
                            {
                                if (excel.OpenExcelSilently(file))
                                {
                                    int totalPages = excel.GetTotalPages();
                                    results.Add((Path.GetFileName(file), totalPages));
                                }
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        UpdateStatus($"处理文件 {Path.GetFileName(file)} 时出错: {ex.Message}");
                    }
                }

                // 导出到CSV
                var csv = new StringBuilder();
                csv.AppendLine("文件名,页数");
                foreach (var result in results)
                {
                    csv.AppendLine($"{result.fileName},{result.pageCount}");
                }

                File.WriteAllText(saveDialog.FileName, csv.ToString(), Encoding.UTF8);
                UpdateStatus($"统计完成！共处理 {results.Count} 个文件。结果已保存到: {saveDialog.FileName}");
            }
            catch (Exception ex)
            {
                MessageBox.Show($"处理过程中出错: {ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                UpdateStatus($"处理失败: {ex.Message}");
            }
            finally
            {
                SetControlsState(true);
                progressBar.Visibility = Visibility.Collapsed;
            }
        }
        private void BtnCalculate_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtExcelPath.Text))
            {
                MessageBox.Show("请先选择Excel文件", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            var saveDialog = new SaveFileDialog
            {
                Filter = "CSV文件|*.csv",
                Title = "保存合计结果",
                FileName = $"合计结果_{DateTime.Now:yyyyMMdd_HHmmss}.csv"
            };

            if (saveDialog.ShowDialog() != true) return;

            try
            {
                SetControlsState(false);
                progressBar.Visibility = Visibility.Visible;
                UpdateStatus("正在计算合计...");

                using (var excel = _officeManager.CreateExcelHelper())
                {
                    if (excel.OpenExcelSilently(txtExcelPath.Text))
                    {
                        var worksheet = excel.GetWorksheet();
                        var lastRow = worksheet.Cells.SpecialCells(Microsoft.Office.Interop.Excel.XlCellType.xlCellTypeLastCell).Row;

                        // 使用字典记录每个key的合计值和已完成数量
                        var sumResults = new Dictionary<string, double>();
                        var completedSum = new Dictionary<string, int>();
                        var completedCounts = new Dictionary<string, int>();
                        var startDates = new Dictionary<string, List<DateTime>>();
                        var endDates = new Dictionary<string, List<DateTime>>();

                        for (int row = 1; row <= lastRow; row++)
                        {
                            var keyCell = worksheet.Cells[row, 2].Text?.ToString();
                            if (!string.IsNullOrWhiteSpace(keyCell))
                            {
                                if (!sumResults.ContainsKey(keyCell))
                                {
                                    //string.Equals(keyCell, "#Y33");
                                    sumResults[keyCell] = 0;
                                    completedSum[keyCell] = 0;
                                    completedCounts[keyCell] = 1;
                                    startDates[keyCell] = new List<DateTime>();
                                    endDates[keyCell] = new List<DateTime>();

                                }
                                else
                                {
                                    completedCounts[keyCell]++;
                                }

                                // 统计合计值
                                var valueCell = worksheet.Cells[row, 10].Text?.ToString();
                                if (double.TryParse(valueCell, out double value))
                                {
                                    sumResults[keyCell] += value;

                                    // 检查状态列（第11列）的值
                                    var statusCell = worksheet.Cells[row, 11].Text?.ToString();
                                    if (!string.IsNullOrWhiteSpace(statusCell))
                                    {
                                        // 这里可以根据实际需要修改判断条件
                                        if (statusCell == "【修正】完了")
                                        {
                                            completedSum[keyCell]++;
                                        }
                                    }

                                }

                                var startDateCell = worksheet.Cells[row, 15].Text?.ToString();
                                if (!string.IsNullOrWhiteSpace(startDateCell))
                                {
                                    if (DateTime.TryParse(startDateCell, out DateTime date))
                                    {
                                        startDates[keyCell].Add(date);
                                    }
                                }

                                var endDateCell = worksheet.Cells[row, 16].Text?.ToString();
                                if (!string.IsNullOrWhiteSpace(endDateCell))
                                {
                                    if (DateTime.TryParse(endDateCell, out DateTime date))
                                    {
                                        endDates[keyCell].Add(date);
                                    }
                                }
                            }
                        }


                        // 导出到CSV
                        var csv = new StringBuilder();
                        csv.AppendLine("項目,ページ数,ファイル数,完了済分,開始日,終了日");
                        foreach (var key in sumResults.Keys)
                        {
                            string minDate = string.Empty;
                            if (startDates[key].Count > 0)
                            {
                                minDate = startDates[key].Min().ToString();
                            }
                            string maxDate = string.Empty;
                            if (endDates[key].Count > 0)
                            {
                                maxDate = endDates[key].Max().ToString();
                            }
                            csv.AppendLine($"{key},{sumResults[key]},{completedCounts[key]},{completedSum[key]},{minDate},{maxDate}");
                        }

                        File.WriteAllText(saveDialog.FileName, csv.ToString(), Encoding.UTF8);
                        UpdateStatus($"计算完成！共处理 {sumResults.Count} 个项目。结果已保存到: {saveDialog.FileName}");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"处理过程中出错: {ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                UpdateStatus($"处理失败: {ex.Message}");
            }
            finally
            {
                SetControlsState(true);
                progressBar.Visibility = Visibility.Collapsed;
            }
        }
        private void SetControlsState(bool enabled)
        {
            btnSelectFolder.IsEnabled = enabled;
            btnExportPages.IsEnabled = enabled;
            btnSelectExcel.IsEnabled = enabled;
            btnCalculate.IsEnabled = enabled;
        }

        private void UpdateStatus(string message)
        {
            txtStatus.Text = message;
        }

        private void btnAggBasePath_Click(object sender, RoutedEventArgs e)
        {

        }


    }



}