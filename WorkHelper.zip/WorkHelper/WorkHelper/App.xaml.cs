﻿using System.Configuration;
using System.Data;
using System.Windows;

namespace WorkHelper
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application
    {
        protected override void OnExit(ExitEventArgs e)
        {
            base.OnExit(e);

            // 确保程序退出时释放资源
            OfficeManager.Instance.Dispose();
        }

        private void Application_DispatcherUnhandledException(object sender,
        System.Windows.Threading.DispatcherUnhandledExceptionEventArgs e)
        {
            // 处理未捕获的异常
            MessageBox.Show($"发生错误: {e.Exception.Message}", "错误",
                          MessageBoxButton.OK, MessageBoxImage.Error);

            // 确保发生异常时也能清理资源
            OfficeManager.Instance.Dispose();

            e.Handled = true;
        }

    }


}
