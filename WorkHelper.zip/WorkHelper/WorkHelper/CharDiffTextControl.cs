﻿using System;
using System.Collections.Generic;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;

namespace WorkHelper
{
    /// <summary>
    /// A control that visually highlights character-level differences in text
    /// </summary>
    public class CharDiffTextControl : UserControl
    {
        private TextBlock _textBlock;

        public static readonly DependencyProperty TextProperty =
            DependencyProperty.Register("Text", typeof(string), typeof(CharDiffTextControl),
                new PropertyMetadata(string.Empty, OnTextChanged));

        public static readonly DependencyProperty DiffIndicesProperty =
            DependencyProperty.Register("DiffIndices", typeof(List<int>), typeof(CharDiffTextControl),
                new PropertyMetadata(null, OnDiffIndicesChanged));

        public static readonly DependencyProperty DiffBackgroundProperty =
            DependencyProperty.Register("DiffBackground", typeof(Brush), typeof(CharDiffTextControl),
                new PropertyMetadata(Brushes.LightPink));

        public string Text
        {
            get => (string)GetValue(TextProperty);
            set => SetValue(TextProperty, value);
        }

        public List<int> DiffIndices
        {
            get => (List<int>)GetValue(DiffIndicesProperty);
            set => SetValue(DiffIndicesProperty, value);
        }

        public Brush DiffBackground
        {
            get => (Brush)GetValue(DiffBackgroundProperty);
            set => SetValue(DiffBackgroundProperty, value);
        }

        public CharDiffTextControl()
        {
            _textBlock = new TextBlock();
            Content = _textBlock;

            // Default styling
            _textBlock.TextWrapping = TextWrapping.Wrap;
            _textBlock.Padding = new Thickness(2);
        }

        private static void OnTextChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = d as CharDiffTextControl;
            control?.UpdateText();
        }

        private static void OnDiffIndicesChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var control = d as CharDiffTextControl;
            control?.UpdateText();
        }

        private void UpdateText()
        {
            _textBlock.Inlines.Clear();

            if (string.IsNullOrEmpty(Text))
            {
                return;
            }

            var diffSet = new HashSet<int>(DiffIndices ?? new List<int>());

            // Process consecutive diff/non-diff segments for better performance
            var currentSegment = new List<char>();
            bool currentIsDiff = false;

            for (int i = 0; i < Text.Length; i++)
            {
                bool isDiff = diffSet.Contains(i);

                if (i == 0)
                {
                    // First character
                    currentIsDiff = isDiff;
                    currentSegment.Add(Text[i]);
                }
                else if (isDiff == currentIsDiff)
                {
                    // Continue current segment
                    currentSegment.Add(Text[i]);
                }
                else
                {
                    // End current segment and start a new one
                    AddSegment(currentSegment, currentIsDiff);
                    currentSegment.Clear();
                    currentSegment.Add(Text[i]);
                    currentIsDiff = isDiff;
                }
            }

            // Add final segment
            if (currentSegment.Count > 0)
            {
                AddSegment(currentSegment, currentIsDiff);
            }
        }

        private void AddSegment(List<char> segment, bool isDiff)
        {
            var run = new Run(new string(segment.ToArray()));

            if (isDiff)
            {
                run.Background = DiffBackground;
                run.FontWeight = FontWeights.Bold;
            }

            _textBlock.Inlines.Add(run);
        }

        /// <summary>
        /// Compute the diff indices for character-level differences between two strings
        /// </summary>
        public static Tuple<List<int>, List<int>> ComputeCharacterDiffs(string text1, string text2)
        {
            // Simplified Myers diff algorithm implementation for character-level diffs
            var diffIndices1 = new List<int>();
            var diffIndices2 = new List<int>();

            if (string.IsNullOrEmpty(text1) || string.IsNullOrEmpty(text2))
            {
                // Handle empty strings
                if (!string.IsNullOrEmpty(text1))
                {
                    for (int i = 0; i < text1.Length; i++)
                    {
                        diffIndices1.Add(i);
                    }
                }

                if (!string.IsNullOrEmpty(text2))
                {
                    for (int i = 0; i < text2.Length; i++)
                    {
                        diffIndices2.Add(i);
                    }
                }

                return new Tuple<List<int>, List<int>>(diffIndices1, diffIndices2);
            }

            // Create a matrix for the LCS (Longest Common Subsequence)
            int[,] lengths = new int[text1.Length + 1, text2.Length + 1];

            // Fill the matrix
            for (int i = 1; i <= text1.Length; i++)
            {
                for (int j = 1; j <= text2.Length; j++)
                {
                    if (text1[i - 1] == text2[j - 1])
                    {
                        lengths[i, j] = lengths[i - 1, j - 1] + 1;
                    }
                    else
                    {
                        lengths[i, j] = Math.Max(lengths[i - 1, j], lengths[i, j - 1]);
                    }
                }
            }

            // Backtrack to find different characters
            int index1 = text1.Length;
            int index2 = text2.Length;

            while (index1 > 0 && index2 > 0)
            {
                if (text1[index1 - 1] == text2[index2 - 1])
                {
                    // Same character, move diagonally
                    index1--;
                    index2--;
                }
                else if (lengths[index1 - 1, index2] >= lengths[index1, index2 - 1])
                {
                    // Character in text1 is not in LCS
                    diffIndices1.Add(index1 - 1);
                    index1--;
                }
                else
                {
                    // Character in text2 is not in LCS
                    diffIndices2.Add(index2 - 1);
                    index2--;
                }
            }

            // Remaining characters are different
            while (index1 > 0)
            {
                diffIndices1.Add(index1 - 1);
                index1--;
            }

            while (index2 > 0)
            {
                diffIndices2.Add(index2 - 1);
                index2--;
            }

            // Reverse to get indices in the correct order
            diffIndices1.Reverse();
            diffIndices2.Reverse();

            return new Tuple<List<int>, List<int>>(diffIndices1, diffIndices2);
        }
    }
}