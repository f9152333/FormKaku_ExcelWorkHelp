﻿using System.Diagnostics;
using System.IO;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Microsoft.Office.Interop;
using Microsoft.Office.Core;
using WorkHelper.Common;


namespace WorkHelper
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private ExcelHelper currentExcel;
        private WordHelper currentWord;
        private SearchMain _searchMain;
        private FileTrackingWindow _fileTrackingWindow;
        private FileSearchWindow _fileSearchWindow;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void TextBox_DragEnter(object sender, DragEventArgs e)
        {
            Debug.WriteLine("TextBox_DragEnter start");

            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effects = DragDropEffects.Copy;
            }
        }

        private void TextBox_Drop(object sender, DragEventArgs e)
        {
            Debug.WriteLine("TextBox_Drop start");

            txtMain.Text = string.Empty;
            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
            foreach (string file in files)
            {
                // 如果判断是文件夹的话 就直接 加到 txtMain 里面
                if (Directory.Exists(file))
                {
                    txtMain.Text += file + Environment.NewLine;
                    continue;
                }
                else
                {
                    Debug.WriteLine(file);
                    string strDirectory = System.IO.Path.GetDirectoryName(file);
                    string strFileName = System.IO.Path.GetFileName(file);
                    // 如果txtMain 内容不是空的话，就加一个换行符
                    if (txtMain.Text != string.Empty)
                    {
                        txtMain.Text += Environment.NewLine;
                    }
                    txtMain.Text += file + Environment.NewLine;
                }
            }
        }

        private void tbfiles_PreviewDragOver(object sender, DragEventArgs e)
        {
            Debug.WriteLine("tbfiles_PreviewDragOver start");
            e.Handled = true;

            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effects = DragDropEffects.Copy;
            }
        }

        private void btnCleanPath_Click(object sender, RoutedEventArgs e)
        {
            // copy textMain to  clipboard
            Clipboard.SetDataObject(txtMain.Text);
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {

                _searchMain = new SearchMain();
            
            _searchMain.Show();

        }

        private void txtSub_Drop(object sender, DragEventArgs e)
        {

        }

        /// <summary>
        ///  新規で開く
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnOpenNew_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                // 把txtMain的内容解析成一个一个的文件路径，然后对文件进行新规打开
                string[] files = txtMain.Text.Split(new string[] { Environment.NewLine }, System.StringSplitOptions.RemoveEmptyEntries);
                foreach (string file in files)
                {
                    Debug.WriteLine(file);
                    if (Directory.Exists(file))
                    {
                        // 使用 Process.Start 打开文件夹
                        Process.Start(new ProcessStartInfo
                        {
                            FileName = file,
                            UseShellExecute = true // 确保使用系统默认应用程序打开
                        });
                    }
                    else
                    {
                        string strFileName = System.IO.Path.GetFileName(file);


                        //判断后缀名，如果是word文件，就用word打开
                        if (OfficeManager.IsWordFile(strFileName))
                        {

                            currentWord = OfficeManager.Instance.CreateWordHelper();

                            if (FileTrackingManager.Instance.ShouldUseTempFile(file))
                            {
                                // 直接使用已存在的临时文件
                                string tempPath = FileTrackingManager.Instance.GetTempPath(file);
                                currentWord.OpenDocument(tempPath);
                            }
                            else
                            { 
                                currentWord.OpenDocumentAsCopy(file); 
                            }

                        }
                        //判断后缀名，如果是excel文件，就用excel打开
                        else if (OfficeManager.IsExcelFile(strFileName))
                        {
                            currentExcel = OfficeManager.Instance.CreateExcelHelper();

                            if (FileTrackingManager.Instance.ShouldUseTempFile(file))
                            {
                                // 直接使用已存在的临时文件
                                string tempPath = FileTrackingManager.Instance.GetTempPath(file);
                                currentExcel.OpenExcel(tempPath);
                            }
                            else
                            {
                                currentExcel.OpenExcelAsCopy(file);
                            }
                        }
                        else
                        {
                            //// 使用 Process.Start 打开文件
                            //Process.Start(new ProcessStartInfo
                            //{
                            //    FileName = file,
                            //    UseShellExecute = true // 确保使用系统默认应用程序打开
                            //});
                            if (MessageBox.Show("这个文件类型不被本工具支持，请联系开发者。", "确认",
    MessageBoxButton.OK, MessageBoxImage.Error) == MessageBoxResult.Yes)
                            {
                                return;
                            }
                        }
                    }
                }
            }
            catch
            {
                MessageBox.Show("選択したファイルやフォルダ確認ください。");
            }
        }


        private void Window_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {
            OfficeManager.Instance.Dispose();
        }


        private void btnTempFolder_Click(object sender, RoutedEventArgs e)
        {
            FileUtils.Temp.OpenTempFolder();
        }

        private void btnExtract_Click(object sender, RoutedEventArgs e)
        {
            var allComments = new List<CommentInfo>();

            // 把txtMain的内容解析成一个一个的文件路径，然后对文件进行新规打开
            string[] files = txtMain.Text.Split(new string[] { Environment.NewLine }, System.StringSplitOptions.RemoveEmptyEntries);
            foreach (string file in files)
            {
                {
                    if (OfficeManager.IsWordFile(file))
                    {
                        var wordHelper = new WordHelper();
                        try
                        {
                            if (wordHelper.OpenDocumentSilently(file))
                            {
                                var comments = wordHelper.GetAllComments(file);
                                allComments.AddRange(comments);
                            }
                        }
                        finally
                        {
                            wordHelper.CleanUp();
                        }
                    }
                    else if (OfficeManager.IsExcelFile(file))
                    {
                        var excelHelper = new ExcelHelper();
                        try
                        {
                            if (excelHelper.OpenExcelSilently(file))
                            {
                                var comments = excelHelper.GetAllComments(file);
                                allComments.AddRange(comments);
                            }
                        }
                        finally
                        {
                            excelHelper.CleanUp();
                        }
                    }
                }
            }
            // 导出所有评论
            var exporter = new CommentExporter();
            exporter.ExportComments(allComments);
        }


        private void btnToTracking_Click(object sender, RoutedEventArgs e)
        {
            if (_fileTrackingWindow == null || !_fileTrackingWindow.IsLoaded)
            {
                _fileTrackingWindow = new FileTrackingWindow();
                _fileTrackingWindow.Show();
            }
            else
            {
                _fileTrackingWindow.Activate();
            }
        }

        private ProgressStatisticsWindow _progressStatsWindow;
        private void btnProgressManage_Click(object sender, RoutedEventArgs e)
        {
            if (_progressStatsWindow == null || !_progressStatsWindow.IsLoaded)
            {
                _progressStatsWindow = new ProgressStatisticsWindow();
                _progressStatsWindow.Show();
            }
            else
            {
                _progressStatsWindow.Activate();
            }
        }

        private void btnSearchFile_Click(object sender, RoutedEventArgs e)
        {
            if (_fileSearchWindow == null || !_fileSearchWindow.IsLoaded)
            {
                _fileSearchWindow = new FileSearchWindow();
                _fileSearchWindow.Show();
            }
            else
            {
                _fileSearchWindow.Activate();
            }
        }

        private FileAnalysisWindow _fileAnalysisWindow ;

        private void btnPageCount_Click(object sender, RoutedEventArgs e)
        {
            if (_fileAnalysisWindow == null || !_fileAnalysisWindow.IsLoaded)
            {
                _fileAnalysisWindow = new FileAnalysisWindow();
                _fileAnalysisWindow.Show();
            }
            else
            {
                _fileAnalysisWindow.Activate();
            }
        }

        CodeReviewExporterWindow _codeReivewWindow;

        private void btnCodeReview_Click(object sender, RoutedEventArgs e)
        {
            if (_codeReivewWindow == null || !_codeReivewWindow.IsLoaded)
            {
                _codeReivewWindow = new CodeReviewExporterWindow();
                _codeReivewWindow.Show();
            }
            else
            {
                _codeReivewWindow.Activate();
            }
        }

        private void btnExcelCompare_Click(object sender, RoutedEventArgs e)
        {
            var excelViewerWindow = new ExcelViewerWindow();
            excelViewerWindow.Show();
        }
    }
}