﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;

namespace WorkHelper
{
    public class FileTrackingInfo
    {
        public string SourcePath { get; set; }
        public string TempPath { get; set; }
        public DateTime SourceLastWriteTime { get; set; }
        public DateTime AsCopyOpenTime { get; set; }
        public string Notes { get; set; }

        public void UpdateAsCopyOpenTime ()
        {
            AsCopyOpenTime = DateTime.Now;
        }

    }

    public class FileTrackingManager
    {
        private const string TRACKING_FILE = "filetracking.json";
        private Dictionary<string, FileTrackingInfo> _trackingInfo;

        public FileTrackingManager()
        {
            LoadTrackingInfo();
        }

        private static readonly object _lock = new object();
        private static FileTrackingManager _instance;
        public static FileTrackingManager Instance
        {
            get
            {
                if (_instance == null)
                {
                    lock (_lock)
                    {
                        if (_instance == null)
                        {
                            _instance = new FileTrackingManager();
                        }
                    }
                }
                return _instance;
            }
        }

        private void LoadTrackingInfo()
        {
            if (File.Exists(TRACKING_FILE))
            {
                string json = File.ReadAllText(TRACKING_FILE);
                _trackingInfo = JsonSerializer.Deserialize<Dictionary<string, FileTrackingInfo>>(json);
            }
            else
            {
                _trackingInfo = new Dictionary<string, FileTrackingInfo>();
            }

            //foreach (var trackItem in _trackingInfo)
            //{
            //    var currentSourceTime = File.GetLastWriteTime(trackItem.Value.SourcePath);
            //    trackItem.Value.SourceLastWriteTime = currentSourceTime;
            //}
            //    FileTrackingManager.Instance.SaveTrackingInfo(); // Save changes to storage
        }

        public void UpdateSourceTime()
        {
            foreach (var trackItem in _trackingInfo)
            {
                var currentSourceTime = File.GetLastWriteTime(trackItem.Value.SourcePath);
                trackItem.Value.SourceLastWriteTime = currentSourceTime;
            }
        }

        public void UpdateSyncTime()
        {
            foreach (var trackItem in _trackingInfo)
            {
                var currentSourceTime = File.GetLastWriteTime(trackItem.Value.SourcePath);
                trackItem.Value.SourceLastWriteTime = currentSourceTime;
            }
        }

        public void SaveTrackingInfo()
        {
            string json = JsonSerializer.Serialize(_trackingInfo, new JsonSerializerOptions { WriteIndented = true });
            File.WriteAllText(TRACKING_FILE, json);
        }

        public void TrackFile(string sourcePath, string tempPath)
        {
            var comment = string.Empty;
            if (_trackingInfo.ContainsKey(sourcePath))
            {
                var oldInfo = _trackingInfo[sourcePath];
                comment = oldInfo.Notes;
            }
            var info = new FileTrackingInfo
            {
                SourcePath = sourcePath,
                TempPath = tempPath,
                SourceLastWriteTime = File.GetLastWriteTime(sourcePath),
                AsCopyOpenTime = DateTime.Now,
                Notes = comment
            };

            _trackingInfo[sourcePath] = info;
            SaveTrackingInfo();
        }

        public bool ShouldUseTempFile(string sourcePath)
        {
            if (!_trackingInfo.ContainsKey(sourcePath))
                return false;

            var info = _trackingInfo[sourcePath];

            // Check if source file has been modified since last tracking
            bool sourceUnchanged = File.GetLastWriteTime(sourcePath) <= info.AsCopyOpenTime;

            // Check if temp file exists and hasn't been modified since AsCopy opened it
            bool tempFileValid = File.Exists(info.TempPath) &&
                               File.GetLastWriteTime(info.TempPath) <= info.AsCopyOpenTime;

            return sourceUnchanged && tempFileValid;
        }

        public string GetTempPath(string sourcePath)
        {
            return _trackingInfo.ContainsKey(sourcePath) ? _trackingInfo[sourcePath].TempPath : null;
        }

        // 清理过期的临时文件
        public void CleanupOldTempFiles(TimeSpan age)
        {
            var expiredEntries = _trackingInfo
                .Where(kvp => DateTime.Now - kvp.Value.AsCopyOpenTime > age)
                .ToList();

            foreach (var entry in expiredEntries)
            {
                if (File.Exists(entry.Value.TempPath))
                {
                    try
                    {
                        File.Delete(entry.Value.TempPath);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Failed to delete temp file {entry.Value.TempPath}: {ex.Message}");
                    }
                }
                _trackingInfo.Remove(entry.Key);
            }

            SaveTrackingInfo();
        }

        public IEnumerable<FileTrackingInfo> GetAllRecords()
        {
            return _trackingInfo.Values;
        }

        public void DeleteRecord(string sourcePath)
        {
            if (_trackingInfo.ContainsKey(sourcePath))
            {
                var info = _trackingInfo[sourcePath];
                if (File.Exists(info.TempPath))
                {
                    try
                    {
                        File.Delete(info.TempPath);
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Failed to delete temp file: {ex.Message}");
                    }
                }
                _trackingInfo.Remove(sourcePath);
                SaveTrackingInfo();
            }
        }
    }
}
