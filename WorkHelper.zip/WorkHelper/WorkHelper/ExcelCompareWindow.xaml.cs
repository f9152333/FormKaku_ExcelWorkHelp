﻿using Microsoft.Office.Interop.Excel;
using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Media;
using WorkHelper.Common;
using Range = Microsoft.Office.Interop.Excel.Range;
using Style = System.Windows.Style;
using Window = System.Windows.Window;

namespace WorkHelper
{
    public partial class ExcelCompareWindow : Window
    {
        private readonly OfficeManager _officeManager;
        private ExcelHelper _leftExcelHelper;
        private ExcelHelper _rightExcelHelper;
        private Workbook _leftWorkbook;
        private Workbook _rightWorkbook;
        private List<string> _leftSheetNames;
        private List<string> _rightSheetNames;
        private readonly List<DiffItem> _diffItems = new List<DiffItem>();
        private int _currentDiffIndex = -1;

        // Data models for grids
        private ObservableCollection<ExcelRowViewModel> _leftGridData;
        private ObservableCollection<ExcelRowViewModel> _rightGridData;

        public ExcelCompareWindow()
        {
            InitializeComponent();
            _officeManager = OfficeManager.Instance;
            _leftGridData = new ObservableCollection<ExcelRowViewModel>();
            _rightGridData = new ObservableCollection<ExcelRowViewModel>();

            btnPrevDiff.IsEnabled = false;
            btnNextDiff.IsEnabled = false;
            btnCompare.IsEnabled = false;
            cmbSheetNames.IsEnabled = false;
        }

        private async void BtnSelectLeftFile_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
            {
                Filter = "Excel文件|*.xlsx;*.xls",
                Title = "选择Excel文件（左侧）"
            };

            if (dialog.ShowDialog() == true)
            {
                txtLeftFile.Text = dialog.FileName;
                UpdateCompareButtonState();

                try
                {
                    // Close existing Excel helper if any
                    if (_leftExcelHelper != null)
                    {
                        _officeManager.ReleaseExcelHelper(_leftExcelHelper);
                        _leftExcelHelper = null;
                    }

                    // Open Excel file silently
                    _leftExcelHelper = _officeManager.CreateExcelHelper();
                    if (await Task.Run(() => _leftExcelHelper.OpenExcelSilently(dialog.FileName, true)))
                    {
                        _leftWorkbook = _leftExcelHelper.GetWorkbook();
                        _leftSheetNames = GetSheetNames(_leftWorkbook);
                        UpdateSheetComboBox();
                        txtStatus.Text = "左侧文件已加载";
                    }
                    else
                    {
                        MessageBox.Show("无法打开左侧Excel文件。", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"打开左侧Excel文件时出错: {ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private async void BtnSelectRightFile_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
            {
                Filter = "Excel文件|*.xlsx;*.xls",
                Title = "选择Excel文件（右侧）"
            };

            if (dialog.ShowDialog() == true)
            {
                txtRightFile.Text = dialog.FileName;
                UpdateCompareButtonState();

                try
                {
                    // Close existing Excel helper if any
                    if (_rightExcelHelper != null)
                    {
                        _officeManager.ReleaseExcelHelper(_rightExcelHelper);
                        _rightExcelHelper = null;
                    }

                    // Open Excel file silently
                    _rightExcelHelper = _officeManager.CreateExcelHelper();
                    if (await Task.Run(() => _rightExcelHelper.OpenExcelSilently(dialog.FileName, true)))
                    {
                        _rightWorkbook = _rightExcelHelper.GetWorkbook();
                        _rightSheetNames = GetSheetNames(_rightWorkbook);
                        UpdateSheetComboBox();
                        txtStatus.Text = "右侧文件已加载";
                    }
                    else
                    {
                        MessageBox.Show("无法打开右侧Excel文件。", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"打开右侧Excel文件时出错: {ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private List<string> GetSheetNames(Workbook workbook)
        {
            var sheetNames = new List<string>();
            foreach (Worksheet sheet in workbook.Worksheets)
            {
                sheetNames.Add(sheet.Name);
            }
            return sheetNames;
        }

        private void UpdateSheetComboBox()
        {
            if (_leftSheetNames != null && _rightSheetNames != null)
            {
                // Find common sheet names
                var commonSheets = _leftSheetNames.Intersect(_rightSheetNames).ToList();
                if (commonSheets.Count > 0)
                {
                    cmbSheetNames.ItemsSource = commonSheets;
                    cmbSheetNames.SelectedIndex = 0;
                    cmbSheetNames.IsEnabled = true;
                    txtStatus.Text = "请选择要比较的工作表";
                }
                else
                {
                    cmbSheetNames.ItemsSource = null;
                    cmbSheetNames.IsEnabled = false;
                    MessageBox.Show("两个Excel文件没有共同的工作表名称。", "警告", MessageBoxButton.OK, MessageBoxImage.Warning);
                }
            }
        }

        private void UpdateCompareButtonState()
        {
            btnCompare.IsEnabled = !string.IsNullOrEmpty(txtLeftFile.Text) && !string.IsNullOrEmpty(txtRightFile.Text) && cmbSheetNames.SelectedItem != null;
        }

        private void CmbSheetNames_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            UpdateCompareButtonState();
            if (cmbSheetNames.SelectedItem != null)
            {
                string selectedSheet = cmbSheetNames.SelectedItem.ToString();
                txtLeftSheetInfo.Text = $"左侧文件: 工作表 '{selectedSheet}'";
                txtRightSheetInfo.Text = $"右侧文件: 工作表 '{selectedSheet}'";
            }
        }

        private async void BtnCompare_Click(object sender, RoutedEventArgs e)
        {
            if (cmbSheetNames.SelectedItem == null)
            {
                MessageBox.Show("请先选择要比较的工作表。", "提示", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            try
            {
                SetControlsState(false);
                txtStatus.Text = "正在比较工作表...";

                string selectedSheet = cmbSheetNames.SelectedItem.ToString();

                bool ignoreCase = chkIgnoreCase.IsChecked == true;
                bool ignoreWhitespace = chkIgnoreWhitespace.IsChecked == true;
                
                await Task.Run(() =>
                {
                    // Load sheet data
                    var leftSheetData = LoadSheetData(_leftWorkbook, selectedSheet);
                    var rightSheetData = LoadSheetData(_rightWorkbook, selectedSheet);

                    // Prepare grid data
                    _leftGridData = PrepareGridData(leftSheetData);
                    _rightGridData = PrepareGridData(rightSheetData);


                    // Compare data and highlight differences
                    CompareSheetsData(leftSheetData, rightSheetData, ignoreCase, ignoreWhitespace);
                });

                // Set up data grids
                SetupDataGrids();

                // Update UI with comparison results
                txtDiffCount.Text = _diffItems.Count.ToString();
                txtTotalDiff.Text = _diffItems.Count.ToString();
                txtCurrentDiff.Text = _diffItems.Count > 0 ? "1" : "0";
                _currentDiffIndex = _diffItems.Count > 0 ? 0 : -1;

                // Enable navigation buttons if there are differences
                btnPrevDiff.IsEnabled = _diffItems.Count > 0;
                btnNextDiff.IsEnabled = _diffItems.Count > 0;

                if (_diffItems.Count > 0)
                {
                    NavigateToDiff(_currentDiffIndex);
                    txtStatus.Text = $"比较完成，找到 {_diffItems.Count} 个差异";
                }
                else
                {
                    txtStatus.Text = "比较完成，未发现差异";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"比较过程中出错: {ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                txtStatus.Text = "比较失败";
            }
            finally
            {
                SetControlsState(true);
            }
        }

        private void SetControlsState(bool enabled)
        {
            btnSelectLeftFile.IsEnabled = enabled;
            btnSelectRightFile.IsEnabled = enabled;
            chkIgnoreCase.IsEnabled = enabled;
            chkIgnoreWhitespace.IsEnabled = enabled;
            cmbSheetNames.IsEnabled = enabled && _leftSheetNames != null && _rightSheetNames != null;
            btnCompare.IsEnabled = enabled && !string.IsNullOrEmpty(txtLeftFile.Text) && !string.IsNullOrEmpty(txtRightFile.Text) && cmbSheetNames.SelectedItem != null;
        }

        private ExcelSheetData LoadSheetData(Workbook workbook, string sheetName)
        {
            var sheetData = new ExcelSheetData();
            Worksheet sheet = workbook.Worksheets[sheetName];
            Range usedRange = sheet.UsedRange;

            sheetData.Rows = usedRange.Rows.Count;
            sheetData.Columns = usedRange.Columns.Count;

            // Get all cell values
            for (int row = 1; row <= sheetData.Rows; row++)
            {
                var rowData = new List<string>();
                for (int col = 1; col <= sheetData.Columns; col++)
                {
                    Range cell = sheet.Cells[row, col];
                    rowData.Add(cell.Value2?.ToString() ?? string.Empty);
                }
                sheetData.Data.Add(rowData);
            }

            return sheetData;
        }

        private ObservableCollection<ExcelRowViewModel> PrepareGridData(ExcelSheetData sheetData)
        {
            var gridData = new ObservableCollection<ExcelRowViewModel>();

            for (int row = 0; row < sheetData.Rows; row++)
            {
                var rowModel = new ExcelRowViewModel { RowIndex = row + 1 };
                for (int col = 0; col < sheetData.Columns; col++)
                {
                    string cellValue = row < sheetData.Data.Count && col < sheetData.Data[row].Count
                        ? sheetData.Data[row][col]
                        : string.Empty;

                    rowModel.Cells.Add(new ExcelCellViewModel
                    {
                        Value = cellValue,
                        Column = col + 1,
                        Row = row + 1,
                        IsDifferent = false
                    });
                }
                gridData.Add(rowModel);
            }

            return gridData;
        }

        private void CompareSheetsData(ExcelSheetData leftData, ExcelSheetData rightData,bool ignoreCase , bool ignoreWhitespace)
        {
            _diffItems.Clear();

            // Determine the maximum number of rows and columns to compare
            int maxRows = Math.Max(leftData.Rows, rightData.Rows);
            int maxCols = Math.Max(leftData.Columns, rightData.Columns);

            for (int row = 0; row < maxRows; row++)
            {
                bool rowHasDiff = false;

                for (int col = 0; col < maxCols; col++)
                {
                    // Get cell values, empty string if out of bounds
                    string leftValue = (row < leftData.Data.Count && col < leftData.Data[row].Count)
                        ? leftData.Data[row][col]
                        : string.Empty;

                    string rightValue = (row < rightData.Data.Count && col < rightData.Data[row].Count)
                        ? rightData.Data[row][col]
                        : string.Empty;

                    // Apply comparison settings
                    if (ignoreCase)
                    {
                        leftValue = leftValue.ToLower();
                        rightValue = rightValue.ToLower();
                    }

                    if (ignoreWhitespace)
                    {
                        leftValue = leftValue.Trim();
                        rightValue = rightValue.Trim();
                    }

                    // Compare values
                    if (leftValue != rightValue)
                    {
                        rowHasDiff = true;

                        // Set the cell as different in both grid data collections
                        if (row < _leftGridData.Count && col < _leftGridData[row].Cells.Count)
                        {
                            _leftGridData[row].Cells[col].IsDifferent = true;
                            _leftGridData[row].HasDifference = true;
                        }

                        if (row < _rightGridData.Count && col < _rightGridData[row].Cells.Count)
                        {
                            _rightGridData[row].Cells[col].IsDifferent = true;
                            _rightGridData[row].HasDifference = true;
                        }

                        // If the cell has text differences, perform character-level diff
                        if (!string.IsNullOrEmpty(leftValue) && !string.IsNullOrEmpty(rightValue))
                        {
                            var charDiffs = GetCharacterDiff(leftValue, rightValue);

                            if (row < _leftGridData.Count && col < _leftGridData[row].Cells.Count)
                            {
                                _leftGridData[row].Cells[col].CharDiffs = charDiffs.Item1;
                            }

                            if (row < _rightGridData.Count && col < _rightGridData[row].Cells.Count)
                            {
                                _rightGridData[row].Cells[col].CharDiffs = charDiffs.Item2;
                            }
                        }
                    }
                }

                // If this row has differences, add to the diff list
                if (rowHasDiff)
                {
                    _diffItems.Add(new DiffItem { RowIndex = row, ColumnIndex = -1 }); // -1 means entire row has differences
                }
            }
        }

        private Tuple<List<CharDiff>, List<CharDiff>> GetCharacterDiff(string text1, string text2)
        {
            // This is a simple character difference implementation
            // For a real app, consider using a proper diff algorithm like Myers diff
            var leftDiffs = new List<CharDiff>();
            var rightDiffs = new List<CharDiff>();

            // Find the longest common subsequence
            int[,] lcs = new int[text1.Length + 1, text2.Length + 1];

            for (int i = 1; i <= text1.Length; i++)
            {
                for (int j = 1; j <= text2.Length; j++)
                {
                    if (text1[i - 1] == text2[j - 1])
                    {
                        lcs[i, j] = lcs[i - 1, j - 1] + 1;
                    }
                    else
                    {
                        lcs[i, j] = Math.Max(lcs[i - 1, j], lcs[i, j - 1]);
                    }
                }
            }

            // Backtrack to find the diff
            int index1 = text1.Length;
            int index2 = text2.Length;

            while (index1 > 0 && index2 > 0)
            {
                if (text1[index1 - 1] == text2[index2 - 1])
                {
                    // Characters are the same - not part of the diff
                    index1--;
                    index2--;
                }
                else if (lcs[index1 - 1, index2] >= lcs[index1, index2 - 1])
                {
                    // Character in text1 is not in text2
                    leftDiffs.Add(new CharDiff { Index = index1 - 1, IsDifferent = true });
                    index1--;
                }
                else
                {
                    // Character in text2 is not in text1
                    rightDiffs.Add(new CharDiff { Index = index2 - 1, IsDifferent = true });
                    index2--;
                }
            }

            // Handle remaining characters
            while (index1 > 0)
            {
                leftDiffs.Add(new CharDiff { Index = index1 - 1, IsDifferent = true });
                index1--;
            }

            while (index2 > 0)
            {
                rightDiffs.Add(new CharDiff { Index = index2 - 1, IsDifferent = true });
                index2--;
            }

            // Return the diffs in reverse order (original text order)
            leftDiffs.Reverse();
            rightDiffs.Reverse();

            return new Tuple<List<CharDiff>, List<CharDiff>>(leftDiffs, rightDiffs);
        }

        private void SetupDataGrids()
        {
            // Configure the left grid
            dgLeftContent.Columns.Clear();
            dgLeftContent.ItemsSource = _leftGridData;

            // Add row header column
            var rowColumn = new DataGridTextColumn
            {
                Header = "#",
                Binding = new Binding("RowIndex"),
                Width = new DataGridLength(40)
            };
            dgLeftContent.Columns.Add(rowColumn);

            // Add data columns
            int maxColumns = _leftGridData.Count > 0
                ? _leftGridData.Max(r => r.Cells.Count)
                : 0;

            for (int i = 0; i < maxColumns; i++)
            {
                var colIndex = i;
                var col = new DataGridTemplateColumn
                {
                    Header = GetExcelColumnName(i + 1),
                    Width = new DataGridLength(120)
                };

                col.CellTemplate = CreateCellDataTemplate(colIndex, true);
                dgLeftContent.Columns.Add(col);
            }

            // Configure the right grid
            dgRightContent.Columns.Clear();
            dgRightContent.ItemsSource = _rightGridData;

            // Add row header column
            rowColumn = new DataGridTextColumn
            {
                Header = "#",
                Binding = new Binding("RowIndex"),
                Width = new DataGridLength(40)
            };
            dgRightContent.Columns.Add(rowColumn);

            // Add data columns
            maxColumns = _rightGridData.Count > 0
                ? _rightGridData.Max(r => r.Cells.Count)
                : 0;

            for (int i = 0; i < maxColumns; i++)
            {
                var colIndex = i;
                var col = new DataGridTemplateColumn
                {
                    Header = GetExcelColumnName(i + 1),
                    Width = new DataGridLength(120)
                };

                col.CellTemplate = CreateCellDataTemplate(colIndex, false);
                dgRightContent.Columns.Add(col);
            }

            // Set row style selectors
            dgLeftContent.RowStyle = CreateRowStyle(true);
            dgRightContent.RowStyle = CreateRowStyle(false);
        }

        private DataTemplate CreateCellDataTemplate(int columnIndex, bool isLeftGrid)
        {
            var template = new DataTemplate();
            var factory = new FrameworkElementFactory(typeof(TextBlock));

            factory.SetBinding(TextBlock.TextProperty, new Binding($"Cells[{columnIndex}].Value"));

            // Set up a data trigger for different cells
            var trigger = new DataTrigger
            {
                Binding = new Binding($"Cells[{columnIndex}].IsDifferent"),
                Value = true
            };
            trigger.Setters.Add(new Setter(TextBlock.BackgroundProperty, new SolidColorBrush(Color.FromRgb(255, 221, 221))));

            var style = new Style(typeof(TextBlock));
            style.Triggers.Add(trigger);
            style.Setters.Add(new Setter(TextBlock.PaddingProperty, new Thickness(4)));

            factory.SetValue(TextBlock.StyleProperty, style);

            // For text-level differences, we would need to use a more complex control with TextBlocks and Runs
            // This is a simplified version

            template.VisualTree = factory;
            return template;
        }

        private Style CreateRowStyle(bool isLeftGrid)
        {
            var style = new Style(typeof(DataGridRow));

            // Set up a data trigger for rows with differences
            var trigger = new DataTrigger
            {
                Binding = new Binding("HasDifference"),
                Value = true
            };

            trigger.Setters.Add(new Setter(DataGridRow.BackgroundProperty, new SolidColorBrush(Color.FromRgb(255, 240, 240))));
            style.Triggers.Add(trigger);

            return style;
        }

        private void BtnPrevDiff_Click(object sender, RoutedEventArgs e)
        {
            if (_diffItems.Count == 0) return;

            _currentDiffIndex--;
            if (_currentDiffIndex < 0) _currentDiffIndex = _diffItems.Count - 1;

            NavigateToDiff(_currentDiffIndex);
        }

        private void BtnNextDiff_Click(object sender, RoutedEventArgs e)
        {
            if (_diffItems.Count == 0) return;

            _currentDiffIndex++;
            if (_currentDiffIndex >= _diffItems.Count) _currentDiffIndex = 0;

            NavigateToDiff(_currentDiffIndex);
        }

        private void NavigateToDiff(int diffIndex)
        {
            if (diffIndex < 0 || diffIndex >= _diffItems.Count) return;

            var diff = _diffItems[diffIndex];
            txtCurrentDiff.Text = (diffIndex + 1).ToString();

            // Scroll to the row
            if (diff.RowIndex < _leftGridData.Count)
            {
                dgLeftContent.ScrollIntoView(_leftGridData[diff.RowIndex]);
                dgRightContent.ScrollIntoView(_rightGridData[diff.RowIndex]);

                // Select the row
                dgLeftContent.SelectedIndex = diff.RowIndex;
                dgRightContent.SelectedIndex = diff.RowIndex;
            }
        }

        private void LeftScroller_ScrollChanged(object sender, ScrollChangedEventArgs e)
        {
            // Synchronize horizontal scrolling between left and right
            if (e.HorizontalChange != 0)
            {
                rightScroller.ScrollToHorizontalOffset(e.HorizontalOffset);
            }
        }

        private void RightScroller_ScrollChanged(object sender, ScrollChangedEventArgs e)
        {
            // Synchronize horizontal scrolling between left and right
            if (e.HorizontalChange != 0)
            {
                leftScroller.ScrollToHorizontalOffset(e.HorizontalOffset);
            }
        }

        private string GetExcelColumnName(int columnNumber)
        {
            // Convert column number to Excel-style column name (A, B, C, ... Z, AA, AB, etc.)
            string columnName = string.Empty;

            while (columnNumber > 0)
            {
                int remainder = (columnNumber - 1) % 26;
                char columnChar = (char)('A' + remainder);
                columnName = columnChar + columnName;
                columnNumber = (columnNumber - 1) / 26;
            }

            return columnName;
        }

        protected override void OnClosing(CancelEventArgs e)
        {
            // Clean up Excel resources
            if (_leftExcelHelper != null)
            {
                _officeManager.ReleaseExcelHelper(_leftExcelHelper);
                _leftExcelHelper = null;
            }

            if (_rightExcelHelper != null)
            {
                _officeManager.ReleaseExcelHelper(_rightExcelHelper);
                _rightExcelHelper = null;
            }

            base.OnClosing(e);
        }
    }

    public class ExcelSheetData
    {
        public int Rows { get; set; }
        public int Columns { get; set; }
        public List<List<string>> Data { get; set; } = new List<List<string>>();
    }

    public class DiffItem
    {
        public int RowIndex { get; set; }
        public int ColumnIndex { get; set; }
    }

    public class CharDiff
    {
        public int Index { get; set; }
        public bool IsDifferent { get; set; }
    }

    public class ExcelRowViewModel : INotifyPropertyChanged
    {
        private int _rowIndex;
        private bool _hasDifference;
        private ObservableCollection<ExcelCellViewModel> _cells = new ObservableCollection<ExcelCellViewModel>();

        public int RowIndex
        {
            get => _rowIndex;
            set
            {
                if (_rowIndex != value)
                {
                    _rowIndex = value;
                    OnPropertyChanged();
                }
            }
        }

        public bool HasDifference
        {
            get => _hasDifference;
            set
            {
                if (_hasDifference != value)
                {
                    _hasDifference = value;
                    OnPropertyChanged();
                }
            }
        }

        public ObservableCollection<ExcelCellViewModel> Cells
        {
            get => _cells;
            set
            {
                if (_cells != value)
                {
                    _cells = value;
                    OnPropertyChanged();
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    public class ExcelCellViewModel : INotifyPropertyChanged
    {
        private string _value;
        private bool _isDifferent;
        private int _row;
        private int _column;
        private List<CharDiff> _charDiffs;

        public string Value
        {
            get => _value;
            set
            {
                if (_value != value)
                {
                    _value = value;
                    OnPropertyChanged();
                }
            }
        }

        public bool IsDifferent
        {
            get => _isDifferent;
            set
            {
                if (_isDifferent != value)
                {
                    _isDifferent = value;
                    OnPropertyChanged();
                }
            }
        }

        public int Row
        {
            get => _row;
            set
            {
                if (_row != value)
                {
                    _row = value;
                    OnPropertyChanged();
                }
            }
        }

        public int Column
        {
            get => _column;
            set
            {
                if (_column != value)
                {
                    _column = value;
                    OnPropertyChanged();
                }
            }
        }

        public List<CharDiff> CharDiffs
        {
            get => _charDiffs;
            set
            {
                _charDiffs = value;
                OnPropertyChanged();
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }

    // Extension method for ExcelHelper
    public static class ExcelHelperExtensions
    {
        public static int GetTotalPages(this ExcelHelper excelHelper)
        {
            if (excelHelper == null) return 0;

            var workbook = excelHelper.GetWorkbook();
            if (workbook == null) return 0;

            int totalPages = 0;

            foreach (Worksheet sheet in workbook.Worksheets)
            {
                // This is an approximation, as Excel doesn't have a direct way to get page count
                // It would actually need to use Excel's print preview functionality
                sheet.PageSetup.FitToPagesWide = 1;
                sheet.PageSetup.FitToPagesTall = false;

                Range usedRange = sheet.UsedRange;
                int approxPages = (int)Math.Ceiling((double)usedRange.Rows.Count / 60); // Rough estimate
                totalPages += approxPages;
            }

            return totalPages;
        }
    }

    // Add this class to implement character-level diff visualization in a TextBlock
    public class CharLevelDiffTextBlock : TextBlock
    {
        public static readonly DependencyProperty TextValueProperty =
            DependencyProperty.Register("TextValue", typeof(string), typeof(CharLevelDiffTextBlock),
                new PropertyMetadata(string.Empty, OnTextValueChanged));

        public static readonly DependencyProperty CharDiffsProperty =
            DependencyProperty.Register("CharDiffs", typeof(List<CharDiff>), typeof(CharLevelDiffTextBlock),
                new PropertyMetadata(null, OnCharDiffsChanged));

        public string TextValue
        {
            get => (string)GetValue(TextValueProperty);
            set => SetValue(TextValueProperty, value);
        }

        public List<CharDiff> CharDiffs
        {
            get => (List<CharDiff>)GetValue(CharDiffsProperty);
            set => SetValue(CharDiffsProperty, value);
        }

        private static void OnTextValueChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var textBlock = d as CharLevelDiffTextBlock;
            textBlock?.UpdateText();
        }

        private static void OnCharDiffsChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var textBlock = d as CharLevelDiffTextBlock;
            textBlock?.UpdateText();
        }

        private void UpdateText()
        {
            Inlines.Clear();

            if (string.IsNullOrEmpty(TextValue) || CharDiffs == null || CharDiffs.Count == 0)
            {
                Inlines.Add(new Run(TextValue ?? string.Empty));
                return;
            }

            // Create runs with highlighted differences
            var diffIndices = new HashSet<int>(CharDiffs.Where(d => d.IsDifferent).Select(d => d.Index));

            for (int i = 0; i < TextValue.Length; i++)
            {
                var run = new Run(TextValue[i].ToString());

                if (diffIndices.Contains(i))
                {
                    run.Background = new SolidColorBrush(Color.FromRgb(255, 204, 204));
                    run.FontWeight = FontWeights.Bold;
                }

                Inlines.Add(run);
            }
        }
    }
}