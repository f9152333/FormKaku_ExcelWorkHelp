﻿using Microsoft.Win32;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Input;
using Path = System.IO.Path;

namespace WorkHelper
{
    /// <summary>
    /// Window1.xaml の相互作用ロジック
    /// </summary>
    public partial class SearchResultsWindow : Window
    {
        private List<SearchResult> _allResults;
        private ICollectionView _resultsView;

        public SearchResultsWindow(List<SearchResult> results)
        {
            InitializeComponent();
            _allResults = results;
            InitializeDataGrid();
        }

        private void InitializeDataGrid()
        {
            dgResults.ItemsSource = _allResults;
            _resultsView = CollectionViewSource.GetDefaultView(dgResults.ItemsSource);
            UpdateStatusBar();
            
        }

        private void UpdateStatusBar()
        {
            // 如果你有状态栏，可以在这里更新统计信息
            // 例如：总结果数、筛选后的结果数等
        }

        private void BtnExportExcel_Click(object sender, RoutedEventArgs e)
        {
            if (_resultsView.Cast<SearchResult>().Count() == 0)
            {
                MessageBox.Show("没有可导出的搜索结果", "提示", MessageBoxButton.OK, MessageBoxImage.Information);
                return;
            }

            var saveFileDialog = new SaveFileDialog
            {
                Filter = "Excel文件|*.xlsx",
                DefaultExt = ".xlsx",
                FileName = $"搜索结果_{DateTime.Now:yyyyMMdd_HHmmss}"
            };

            if (saveFileDialog.ShowDialog() == true)
            {
                try
                {
                    Mouse.OverrideCursor = Cursors.Wait;

                    var documentSearcher = new DocumentSearcher();
                    documentSearcher.ExportResultsToExcel(saveFileDialog.FileName);
                    MessageBox.Show("导出完成！", "提示", MessageBoxButton.OK, MessageBoxImage.Information);

                }
                catch (Exception ex)
                {
                    MessageBox.Show($"导出失败: {ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                }
                finally
                {
                    Mouse.OverrideCursor = null;
                }
            }
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            // 清除筛选
            txtFilter.Clear();
            _resultsView.Refresh();
            UpdateStatusBar();
        }

        private void TxtFilter_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (_resultsView == null) return;

            string filterText = txtFilter.Text.ToLower();
            if (string.IsNullOrWhiteSpace(filterText))
            {
                _resultsView.Filter = null;
            }
            else
            {
                _resultsView.Filter = obj =>
                {
                    if (obj is SearchResult result)
                    {
                        return result.FilePath.ToLower().Contains(filterText) ||
                               result.FileType.ToLower().Contains(filterText) ||
                               result.Location.ToLower().Contains(filterText) ||
                               result.Context.ToLower().Contains(filterText) ||
                               result.Keyword.ToLower().Contains(filterText);
                    }
                    return false;
                };
            }
            UpdateStatusBar();
        }

        private void DgResults_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            if (dgResults.SelectedItem is SearchResult result)
            {
                OpenFileAndLocate((SearchResult)dgResults.SelectedItem);
            }
        }

        private void MenuItemOpenFile_Click(object sender, RoutedEventArgs e)
        {
            if (dgResults.SelectedItem is SearchResult result)
            {
                OpenFileAndLocate((SearchResult)dgResults.SelectedItem);
            }
        }

        private void MenuItemOpenFileLocation_Click(object sender, RoutedEventArgs e)
        {
            if (dgResults.SelectedItem is SearchResult result)
            {
                try
                {
                    string argument = $"/select,\"{result.FilePath}\"";
                    Process.Start("explorer.exe", argument);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"无法打开文件位置: {ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void MenuItemCopyPath_Click(object sender, RoutedEventArgs e)
        {
            if (dgResults.SelectedItem is SearchResult result)
            {
                try
                {
                    Clipboard.SetText(result.FilePath);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"复制路径失败: {ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void MenuItemCopyContext_Click(object sender, RoutedEventArgs e)
        {
            if (dgResults.SelectedItem is SearchResult result)
            {
                try
                {
                    Clipboard.SetText(result.Context);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"复制上下文失败: {ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }

        private void OpenFile(string filePath)
        {
            try
            {
                if (File.Exists(filePath))
                {
                    Process.Start(new ProcessStartInfo
                    {
                        FileName = filePath,
                        UseShellExecute = true
                    });
                }
                else
                {
                    MessageBox.Show("文件不存在", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"打开文件失败: {ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void OpenFileAndLocate(SearchResult result)
        {
            try
            {
                if (!File.Exists(result.FilePath))
                {
                    MessageBox.Show("文件不存在", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                    return;
                }

                if (result.FileType == "Word" || result.FileType == "Excel")
                {
                    var documentSearcher = new DocumentSearcher();
                    documentSearcher.OpenAndLocate(result);
                }
                else
                {
                    // 对于其他类型的文件，使用默认程序打开
                    Process.Start(new ProcessStartInfo
                    {
                        FileName = result.FilePath,
                        UseShellExecute = true
                    });
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"打开文件失败: {ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        public void UpdateResults(List<SearchResult> results)
        {
            _allResults = results;
            dgResults.ItemsSource = _allResults;
            _resultsView = CollectionViewSource.GetDefaultView(dgResults.ItemsSource);

            // 重新应用筛选器
            if (!string.IsNullOrWhiteSpace(txtFilter.Text))
            {
                TxtFilter_TextChanged(txtFilter, null);
            }

            UpdateStatusBar();
        }

    }
}
