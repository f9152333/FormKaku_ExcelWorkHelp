﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Input;
using WorkHelper.Common;

namespace WorkHelper
{
    public class SearchFileResult
    {
        public string FileName { get; set; }
        public string FilePath { get; set; }
        public string FilePathForShow { get; set; }
        public string FileType { get; set; }
        public DateTime LastModified { get; set; }
    }

    public partial class FileSearchWindow : Window
    {
        private readonly OfficeManager _officeManager;

        public FileSearchWindow()
        {
            InitializeComponent();
            _officeManager = OfficeManager.Instance;
        }

        private void BtnSelectFolder_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFolderDialog
            {
                Title = "选择搜索目录"
            };

            if (dialog.ShowDialog() == true)
            {
                txtFolderPath.Text = dialog.FolderName;
            }
        }

        private async void BtnSearch_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFolderPath.Text))
            {
                MessageBox.Show("请选择搜索目录", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            if (string.IsNullOrWhiteSpace(txtKeyword.Text))
            {
                MessageBox.Show("请输入搜索关键字", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                SetControlsState(false);
                progressBar.Visibility = Visibility.Visible;
                UpdateStatus("正在搜索文件...");

                var searchKeyword = txtKeyword.Text;
                var searchPath = txtFolderPath.Text;

                var results = await Task.Run(() =>
                {
                    var searchResults = SearchFiles(searchPath, searchKeyword);
                    return searchResults;
                });

                // 在主线程上更新 UI
                Dispatcher.Invoke(() =>
                {
                    dgResults.ItemsSource = results;
                    UpdateStatus($"搜索完成，找到 {results.Count} 个文件。双击可打开文件，右键可以只读打开。");
                });
            }
            catch (Exception ex)
            {
                MessageBox.Show($"搜索过程中出错: {ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                UpdateStatus($"搜索失败: {ex.Message}");
            }
            finally
            {
                SetControlsState(true);
                progressBar.Visibility = Visibility.Collapsed;
            }
        }

        private List<SearchFileResult> SearchFiles(string directoryPath, string keyword)
        {
            var results = new List<SearchFileResult>();
            var files = Directory.GetFiles(directoryPath, "*.*", SearchOption.AllDirectories)
                .Where(f => OfficeManager.IsExcelFile(f) || OfficeManager.IsWordFile(f))
                .Where(f => Path.GetFileName(f).ToLower().Contains(keyword.ToLower()));

            foreach (var file in files)
            {
                string fileType = OfficeManager.IsWordFile(file) ? "Word" : "Excel";
                results.Add(new SearchFileResult
                {
                    FileName = Path.GetFileName(file),
                    FilePath = file,
                    FilePathForShow = Path.GetRelativePath(directoryPath, file).Replace(Path.GetFileName(file),""),
                    FileType = fileType,
                    LastModified = File.GetLastWriteTime(file)
                });
            }

            return results.OrderByDescending(r => r.LastModified).ToList();
        }

        private void DgResults_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {
            var selectedResult = dgResults.SelectedItem as SearchFileResult;
            if (selectedResult != null)
            {
                OpenFile(selectedResult,false);
            }
        }

        private void OpenFile(SearchFileResult file, bool readOnly = true)
        {
            try
            {
                if (file.FileType == "Word")
                {
                    var wordHelper = _officeManager.CreateWordHelper();
                    if (readOnly)
                    {
                        wordHelper.OpenDocumentReadOnly(file.FilePath);
                    }
                    else
                    {
                        wordHelper.OpenDocument(file.FilePath);
                    }
                }
                else if (file.FileType == "Excel")
                {
                    var excelHelper = _officeManager.CreateExcelHelper();
                    if(readOnly)
                    {
                        excelHelper.OpenExcelReadOnly(file.FilePath);
                    }
                    else
                    {
                        excelHelper.OpenExcel(file.FilePath);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"打开文件时出错: {ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void SetControlsState(bool enabled)
        {
            btnSelectFolder.IsEnabled = enabled;
            btnSearch.IsEnabled = enabled;
            txtKeyword.IsEnabled = enabled;
        }

        private void UpdateStatus(string message)
        {
            if (!Dispatcher.CheckAccess())
            {
                Dispatcher.Invoke(() => UpdateStatus(message));
                return;
            }
            txtStatus.Text = message;
        }

        private void MenuItemOpenFile_Click(object sender, RoutedEventArgs e)
        {
            var selectedResult = dgResults.SelectedItem as SearchFileResult;
            if (selectedResult != null)
            {
                OpenFile(selectedResult);
            }
        }
    }
}