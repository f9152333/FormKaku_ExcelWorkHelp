﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Input;
using WorkHelper.Common;

namespace WorkHelper
{
    /// <summary>
    /// Excel文件内容查看器，用于显示Excel文件的所有工作表内容
    /// </summary>
    public partial class ExcelViewerWindow : Window
    {
        private readonly OfficeManager _officeManager;

        public ExcelViewerWindow()
        {
            InitializeComponent();
            _officeManager = OfficeManager.Instance;
        }

        /// <summary>
        /// 浏览按钮点击事件，打开文件选择对话框
        /// </summary>
        private void BtnBrowse_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
            {
                Filter = "Excel文件|*.xlsx;*.xls;*.xlsm",
                Title = "选择Excel文件"
            };

            if (dialog.ShowDialog() == true)
            {
                txtFilePath.Text = dialog.FileName;
            }
        }

        /// <summary>
        /// 导出按钮点击事件，获取并显示Excel文件内容
        /// </summary>
        private async void BtnExport_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtFilePath.Text))
            {
                MessageBox.Show("请先选择Excel文件", "提示", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            try
            {
                SetControlsEnabled(false);
                Mouse.OverrideCursor = Cursors.Wait;
                txtStatus.Text = "正在读取Excel文件内容...";
                txtContent.Clear();

                var excelHelper = _officeManager.CreateExcelHelper();
                var filePath = txtFilePath.Text;

                await Task.Run(() =>
                {
                    // 使用静默方式打开Excel文件
                    if (excelHelper.OpenExcelSilently(filePath))
                    {
                        // 获取所有工作表内容
                        List<ExcelHelper.SheetContent> allSheets = excelHelper.GetDocumentContent();

                        // 在UI线程上更新内容
                        Dispatcher.Invoke(() =>
                        {
                            var contentBuilder = new StringBuilder();

                            foreach (var sheet in allSheets)
                            {
                                // 添加工作表标题
                                contentBuilder.AppendLine($"========== 工作表: {sheet.SheetName} (索引: {sheet.SheetIndex}) ==========");
                                contentBuilder.AppendLine();

                                // 添加工作表内容
                                contentBuilder.AppendLine(sheet.Content);
                                contentBuilder.AppendLine();
                                contentBuilder.AppendLine();
                            }

                            // 显示内容
                            txtContent.Text = contentBuilder.ToString();

                            // 更新状态
                            txtStatus.Text = $"已成功读取 {allSheets.Count} 个工作表的内容";
                        });
                    }
                    else
                    {
                        Dispatcher.Invoke(() =>
                        {
                            txtStatus.Text = "无法打开Excel文件";
                            MessageBox.Show("无法打开Excel文件，请确认文件路径正确且文件未被其他程序占用", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                        });
                    }
                });
            }
            catch (Exception ex)
            {
                txtStatus.Text = $"处理出错: {ex.Message}";
                MessageBox.Show($"处理Excel文件时出错: {ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                SetControlsEnabled(true);
                Mouse.OverrideCursor = null;
            }
        }

        /// <summary>
        /// 设置控件是否启用
        /// </summary>
        private void SetControlsEnabled(bool enabled)
        {
            // 确保在UI线程上执行
            if (Dispatcher.CheckAccess())
            {
                txtFilePath.IsEnabled = enabled;
                btnBrowse.IsEnabled = enabled;
                btnExport.IsEnabled = enabled;
            }
            else
            {
                Dispatcher.Invoke(() => SetControlsEnabled(enabled));
            }
        }
    }
}