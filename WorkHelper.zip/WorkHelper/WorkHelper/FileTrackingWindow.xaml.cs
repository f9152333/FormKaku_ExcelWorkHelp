﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using WorkHelper.Common;
using Path = System.IO.Path;

namespace WorkHelper
{
    /// <summary>
    /// FileTrackingWindow.xaml の相互作用ロジック
    /// </summary>

    public partial class FileTrackingWindow : Window
    {
        private readonly FileTrackingManager _trackingManager;
        private ObservableCollection<FileTrackingViewModel> _trackingRecords;
        private ICollectionView _trackingView;

        public FileTrackingWindow()
        {
            InitializeComponent();
            _trackingManager = FileTrackingManager.Instance;
            _trackingRecords = new ObservableCollection<FileTrackingViewModel>();
            LoadTrackingRecords();
        }

        private void LoadTrackingRecords()
        {
            _trackingRecords.Clear();
            _trackingManager.UpdateSourceTime();
            _trackingManager.SaveTrackingInfo();
            foreach (var record in _trackingManager.GetAllRecords())
            {
                _trackingRecords.Add(new FileTrackingViewModel(record));
            }

            _trackingView = CollectionViewSource.GetDefaultView(_trackingRecords);
            dgTracking.ItemsSource = _trackingView;
            UpdateStatusBar();
        }

        private void UpdateStatusBar()
        {
            txtTotalCount.Text = $"总记录数：{_trackingRecords.Count}";
        }

        private void BtnRefresh_Click(object sender, RoutedEventArgs e)
        {
            LoadTrackingRecords();
        }

        private void BtnCleanup_Click(object sender, RoutedEventArgs e)
        {
            if (MessageBox.Show("确定要清理超过7天的临时文件吗？", "确认",
                MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
            {
                _trackingManager.CleanupOldTempFiles(TimeSpan.FromDays(7));
                LoadTrackingRecords();
            }
        }

        private void TxtFilter_TextChanged(object sender, TextChangedEventArgs e)
        {
            if (_trackingView != null)
            {
                _trackingView.Filter = item =>
                {
                    var record = item as FileTrackingViewModel;
                    var filter = txtFilter.Text.ToLower();
                    return record.SourcePath.ToLower().Contains(filter) || record.Notes.ToLower().Contains(filter)
                           ;
                };
            }
        }

        private void DgTracking_MouseDoubleClick(object sender, System.Windows.Input.MouseButtonEventArgs e)
        {
            var hit = VisualTreeHelper.HitTest(dgTracking, e.GetPosition(dgTracking));
            DependencyObject current = hit?.VisualHit;

            // 向上遍历可视化树，直到找到DataGridCell
            while (current != null && !(current is DataGridCell))
            {
                current = VisualTreeHelper.GetParent(current);
            }

            var cell = current as DataGridCell;

            if (cell == null) return;
            if (cell.Column.Header.ToString() == "备注")
            {
                return;
            }

            var selectedRecord = dgTracking.SelectedItem as FileTrackingViewModel;
            if (selectedRecord != null)
            {
                OpenFile(selectedRecord);
            }
        }

        private void OpenFile(FileTrackingViewModel record)
        {
            try
            {
                if (File.Exists(record.TempPath))
                {
                    Process.Start(new ProcessStartInfo(record.TempPath) { UseShellExecute = true });
                }
                else
                {
                    MessageBox.Show("临时文件不存在。", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"打开文件时出错：{ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void MenuItemOpenFile_Click(object sender, RoutedEventArgs e)
        {
            var selectedRecord = dgTracking.SelectedItem as FileTrackingViewModel;
            if (selectedRecord != null)
            {
                OpenFile(selectedRecord);
            }
        }

        private void MenuItemOpenSourceLocation_Click(object sender, RoutedEventArgs e)
        {
            var selectedRecord = dgTracking.SelectedItem as FileTrackingViewModel;
            if (selectedRecord != null)
            {
                OpenFileLocation(selectedRecord.SourcePath);
            }
        }

        private void MenuItemOpenTempLocation_Click(object sender, RoutedEventArgs e)
        {
            var selectedRecord = dgTracking.SelectedItem as FileTrackingViewModel;
            if (selectedRecord != null)
            {
                OpenFileLocation(selectedRecord.TempPath);
            }
        }

        private void OpenFileLocation(string filePath)
        {
            try
            {
                if (File.Exists(filePath))
                {
                    Process.Start("explorer.exe", $"/select,\"{filePath}\"");
                }
                else
                {
                    MessageBox.Show("文件不存在。", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"打开文件位置时出错：{ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }

        private void MenuItemCopySourcePath_Click(object sender, RoutedEventArgs e)
        {
            var selectedRecord = dgTracking.SelectedItem as FileTrackingViewModel;
            if (selectedRecord != null)
            {
                Clipboard.SetText(selectedRecord.SourcePath);
            }
        }

        private void MenuItemCopyTempPath_Click(object sender, RoutedEventArgs e)
        {
            var selectedRecord = dgTracking.SelectedItem as FileTrackingViewModel;
            if (selectedRecord != null)
            {
                Clipboard.SetText(selectedRecord.TempPath);
            }
        }

        private void MenuItemDeleteRecord_Click(object sender, RoutedEventArgs e)
        {
            if (dgTracking.SelectedItems == null 
                || dgTracking.SelectedItems.Count == 0 
                || MessageBox.Show("确定要删除这些记录吗？", "确认",
                   MessageBoxButton.YesNo, MessageBoxImage.Question) != MessageBoxResult.Yes)
            {
                return;
            }

            foreach (var item in dgTracking.SelectedItems)
            {
                var selectedRecord = item as FileTrackingViewModel;
                if (selectedRecord != null)
                {
                     _trackingManager.DeleteRecord(selectedRecord.SourcePath);
                }
            }

            LoadTrackingRecords();
        }

        private void MenuItemSync_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                //dgTracking.SelectedItems 選択されたアイテムたち
                
                foreach (var item in dgTracking.SelectedItems)
                {
                    var selectedRecord = item as FileTrackingViewModel;
                    if (File.Exists(selectedRecord.SourcePath))
                    {
                        File.Copy(selectedRecord.SourcePath, selectedRecord.TempPath, true);
                        selectedRecord.UpdateSyncTime();
                    }
                    else
                    {
                        MessageBox.Show("源文件已不存在。", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
                LoadTrackingRecords();

            }

            catch (Exception ex)
            {
                MessageBox.Show($"拉取源文件时出错：{ex.Message}", "错误", MessageBoxButton.OK, MessageBoxImage.Error);
            }

        }

        private void btnSyncNew_Click(object sender, RoutedEventArgs e)
        {

        }

        private void dgTracking_Drop(object sender, DragEventArgs e)
        {
            Debug.WriteLine("TextBox_Drop start");

            // 创建临时文件夹（如果不存在）
            string tempFolder = FileUtils.Temp.tempPath;
            Directory.CreateDirectory(tempFolder);

            string[] files = (string[])e.Data.GetData(DataFormats.FileDrop);
            foreach (string file in files)
            {
                // 如果判断是文件夹的话 就直接 加到 txtMain 里面
                if (Directory.Exists(file))
                {
                    continue;
                }
                else
                {
                    Debug.WriteLine(file);

                    // 生成临时文件路径
                    string tempFilePath = Path.Combine(tempFolder,
                        $"{Path.GetFileNameWithoutExtension(file)}_{Guid.NewGuid()}{Path.GetExtension(file)}");

                    // 复制源文件到临时文件
                    File.Copy(file, tempFilePath);

                    FileTrackingManager.Instance.TrackFile(file, tempFilePath);
                }
            }

            LoadTrackingRecords();

        }

        private void dgTracking_DragEnter(object sender, DragEventArgs e)
        {
            //Debug.WriteLine("dgTracking_DragEnter");

            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effects = DragDropEffects.Copy;
            }
        }

        private void dgTracking_PreviewDragOver(object sender, DragEventArgs e)
        {
            //Debug.WriteLine("dgTracking_PreviewDragOver");

            e.Handled = true;

            if (e.Data.GetDataPresent(DataFormats.FileDrop))
            {
                e.Effects = DragDropEffects.Copy;
            }
        }


        private void searchBtn_Click(object sender, RoutedEventArgs e)
        {
            if (_trackingView != null)
            {
                _trackingView.Filter = item =>
                {
                    var record = item as FileTrackingViewModel;
                    var filter = txtFilter.Text.ToLower();
                    return record.SourcePath.ToLower().Contains(filter) || record.Notes.ToLower().Contains(filter)
                           ;
                };
            }
        }
    }

    public class FileTrackingViewModel : INotifyPropertyChanged
    {
        private readonly FileTrackingInfo _info;
        private string _notes;

        public FileTrackingViewModel(FileTrackingInfo info)
        {
            _info = info;
            _notes = info.Notes ?? string.Empty; // Add notes from FileTrackingInfo

        }

        public string SourceFileName => System.IO.Path.GetFileName(_info.SourcePath);
        public string SourcePath => _info.SourcePath;
        public string TempPath => _info.TempPath;
        public string TempFileName => System.IO.Path.GetFileName(_info.TempPath); 
        public DateTime SourceLastWriteTime => _info.SourceLastWriteTime;
        public DateTime AsCopyOpenTime => _info.AsCopyOpenTime;

        public string ShortSPath
        {
            get
            {
                if(string.IsNullOrEmpty(_info.SourcePath) )
                    return string.Empty;

                string spath = _info.SourcePath.Replace("\\\\S98a150\\官公ソリューション第一部\\DGS_1S\\NTC\\70_RFSリプレース\\100_受注後作業\\", "");
                return spath;
            }

        }

        public string Notes
        {
            get => _notes;
            set
            {
                if (_notes != value)
                {
                    _notes = value;
                    _info.Notes = value; // Update the underlying FileTrackingInfo
                    OnPropertyChanged(nameof(Notes));
                    FileTrackingManager.Instance.SaveTrackingInfo(); // Save changes to storage
                }
            }
        }

        public string Status
        {
            get
            {
                if (!File.Exists(SourcePath))
                    return "源文件不存在";
                if (!File.Exists(TempPath))
                    return "临时文件不存在";

                var currentSourceTime = File.GetLastWriteTime(SourcePath);
                if (currentSourceTime > AsCopyOpenTime)
                    return "源文件已更新";

                var tempFileTime = File.GetLastWriteTime(TempPath);
                if (tempFileTime > AsCopyOpenTime)
                    return "临时文件已修改";

                return "正常";
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        protected virtual void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        public void UpdateSyncTime()
        {
            _info.UpdateAsCopyOpenTime();
        }
    }
}
